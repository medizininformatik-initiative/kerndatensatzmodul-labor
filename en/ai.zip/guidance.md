# Guidance - MII IG Laborbefund v2027.0.0-ci

* [**Table of Contents**](toc.md)
* **Guidance**

## Guidance

The elements of this module and their meaning are described by the [logical model](logical-models.md); the [UML diagrams](uml-diagrams.md) show how report, tests, specimen and order relate.

Laboratory reports group tests performed by a medical laboratory. They record whether a report is preliminary or final and several clinically relevant timestamps. A tabular mapping is available on [Laboratory timestamps](laboratory-timestamps.md).

This page introduces the module and points at the subjects treated in detail on their own pages:

* [Laboratory Timestamps](laboratory-timestamps.md) — the clinical reference time and the other times a report records
* [Interpretations and Comments](interpretation.md) — the coded assessment of a result, comments, and interpretation-affecting properties
* [Specimen](specimen.md) — how the specimen is represented, reusing the Biobank module

