# Changelog - MII IG Laborbefund v2027.0.0-ci

* [**Table of Contents**](toc.md)
* **Changelog**

## Changelog

### Version: 2027.0.0

Changes compared to the ballot version 2027.0.0-ballot. They implement the release report for 2027 ([kerndatensatz-meta#233](https://github.com/medizininformatik-initiative/kerndatensatz-meta/issues/233)).

#### FHIR / Content Changes:

##### MII_PR_Labor_Laborbefund

* **Breaking change:** imagingStudy: excluded (`0..0`), as in the HL7 Europe Laboratory Report (`DiagnosticReport-eu-lab`). A laboratory report does not refer to an ImagingStudy. The element was not Must Support; instances carrying it are no longer valid (issue #141).

##### MII_PR_Labor_Laboruntersuchung

* performer: **NEW** as Must Support, for the performing laboratory (organization). As on the laboratory report, `reference` and `identifier` are Must Support as well. Cardinality (`0..*`) and target types remain those of the base resource (issue #142).

##### MII_CPS_Labor_CapabilityStatement

* Observation: search parameter `performer` **NEW**, optional (SHOULD). For searches by performing laboratory, the DiagnosticReport search parameter `performer` is mandatory (SHALL).

##### Examples

* The laboratory test examples carry a `performer.identifier` in addition to `performer.reference`.
* `fix:` `performer.display` in the laboratory test examples matches the name of the referenced example organization ("Zentrallabor Beispielklinikum" instead of "Zentrallabor des IKCL").
* `fix:` `mii-exa-labor-laborwert-data-absent-reason` no longer carries an interpretation and a reference range; without a value there is nothing to interpret (issue #117).
* `fix:` All laboratory examples carry the versioned `meta.profile` and the test data label; `…-ratio` and `…-range` lacked both (issue #118).
* The examples form one case: an order for renal diagnostics, one report grouping all five laboratory tests, and three specimens of the same patient (venous blood, 24-hour urine, spot urine). Every test refers to the order and to its specimen, and every test has an identifier of its own (issue #122).
* **NEW**: `mii-exa-labor-laborwert-haemolyse` — potassium from the haemolysed blood specimen, reported with a value, interpretation H and the interpretation-affecting property. The creatinine example no longer carries the property.
* `mii-exa-labor-laborwert-data-absent-reason` is creatinine in spot urine, not performed because the urine sediment used up the specimen.

#### Implementation Guide:

* The project context (relationships to other modules, microbiology data in the Microbiology module) is now part of the [home page](index.md); the separate page Project Context has been removed.

### Version: 2027.0.0-ballot

Ballot version for 2027.0.0. It contains the following changes compared to the previous version 2026.0.3.

#### FHIR / Content Changes:

##### General:

* All profiles, ValueSets, the CapabilityStatement and the ImplementationGuide resource carry CRMI metadata (shareable, publishable, ValueSets additionally computable), including approval and review date, effective period, version policy, package provenance and contributors. See [Metadata Overview](metadata.md).
* The package id is now `de.medizininformatikinitiative.kerndatensatz.laborbefund`, which is the id the module is distributed under. The repository previously declared `…kerndatensatz.labor`, so a consumer following the packageId stated in the guide could not resolve the package. The canonical is unaffected.
* Pattern and fixed-value codings use unversioned system URLs; a versioned `system` URL would not match in a pattern. The ValueSet compositions remain version-bound.
* Extension references in `type.profile` carry no version either. An extension slice matches on `Extension.url`, a `uri` without a version in the instance, so a version there fixes something that plays no part in matching. Which package version applies is stated in the dependencies; `pin-canonicals` fixes versions in the published output.
* `Coding.version` is flagged Must Support on `Observation.code`, `Observation.valueCodeableConcept` and `ServiceRequest.code`.
* The Meta module dependency is raised from 2026.0.0 to `2027.0.0-ballot`, the version this module is balloted alongside. The CapabilityStatement references that module's Observation `interpretation` search parameter.

##### MII_PR_Labor_Laborbefund and MII_PR_Labor_Laboruntersuchung

* category: `category` is sliced, open, with one mandatory slice carrying the mandatory HL7 coding — `$v2-0074#LAB` on the laboratory report, `$observation-category#laboratory` on the laboratory test. LOINC `26436-6` stays permitted as a further coding but is no longer required. The slicing deliberately sits on `category`, not on `category.coding`: `category` is `1..*`, and constraints below a repeating element apply to every repetition, so on `category.coding` every further category would have to repeat the mandatory codes. A laboratory area belongs beside the mandatory slice as its own `category` entry. The slice names changed — `v2-lab` and `observation-category`; in 2026.0.3 they were `lab-category`. Names appear in validator messages and in profile diffs. Measured against the category shapes of every release since 2025.0.2, including the microbiology module's: all validate.

##### MII_PR_Labor_Laboruntersuchung

* basedOn: **NEW** on the laboratory test — reference to the laboratory order it is based on. `0..*`, constrained to `Reference(ServiceRequest)` and flagged Must Support (issue #82). The cardinality stays that of the base profile; `basedOn` is mandatory only on the laboratory report, and has been so unchanged since 2025.0.2.
* code: The binding moves from `code` onto the new open slice `code.coding[loinc]`, is tightened from `preferred` to `extensible`, and points at a different IPS ValueSet — `results-laboratory-pathology-observations-uv-ips` instead of `results-laboratory-observations-uv-ips`. `Observation.code` itself no longer carries a binding.
* valueCodeableConcept: Extensible binding to the new ValueSet [Coded laboratory result](ValueSet-mii-vs-labor-laborergebnis-codiert.md), which combines the qualitative and semiquantitative result ValueSets. The slices `qualitativ` and `semiquantitativ` originally foreseen have been dropped, because the two ValueSets overlap and can therefore not be discriminated.
* interpretation: Extensible binding to the new ValueSet [Interpretation](ValueSet-mii-vs-labor-interpretation.md), a restricted selection from HL7 v3 ObservationInterpretation (`L`, `LU`, `N`, `H`, `HU`). Locally common scales such as `--, -, N, +, ++` or `L N H` map onto these; beyond the "alarm" limits the abnormal codes `A`, `HH`, `LL` and `AA` may additionally be used.
* category: Definition made precise ("classification of the laboratory test within the diagnostic discipline and the laboratory group").
* `fix:` Invariant mii-lab-2: the expression `hasMember.exists() xor value.exists().not() implies dataAbsentReason.exists()` did not evaluate as described and now reads `hasMember.exists() or value.exists() or dataAbsentReason.exists()` — at least one of the three elements has to be present.

##### MII_CPS_Labor_CapabilityStatement

* Observation: search parameter `based-on` is now mandatory (SHALL); it had been commented out.
* Observation: search parameter `interpretation` **NEW** and mandatory (SHALL). R4 defines no such search parameter; the definition in the Meta module is referenced instead, with identical code and type.
* ServiceRequest: search parameter `requester` removed (issue #82).

##### ValueSets

* **NEW**: MII_VS_Labor_Interpretation — a restricted selection from HL7 v3 ObservationInterpretation for assessing a laboratory result.
* **NEW**: MII_VS_Labor_Laborergebnis_Codiert — the qualitative and semiquantitative result ValueSets combined.
* MII_VS_Labor_Laborbereich: displays switched to the LOINC preferred terms (for example "Blood bank studies (set)" instead of "BLOOD BANK STUDIES"). The list of concepts itself is unchanged.
* The CodeSystem references from hl7.terminology.r4 are version-bound (v2-0074 3.0.0, v2-0203 5.0.0, v3-ObservationInterpretation 4.0.0), because the package arrives in two states and resolution would otherwise be ambiguous.

##### Examples

* `mii-exa-labor-laborwert-ratio` states its result as `valueQuantity` with the composed UCUM unit `mg/(24.h)` instead of as a `valueRatio`. A ratio cannot be reached through `value-quantity` — the R4 expression is `(Observation.value as Quantity) | (Observation.value as SampledData)` — while the CapabilityStatement requires that parameter as SHALL. The instance id keeps its `-ratio` suffix, because the URL has been published before.
* The examples are named after what they contain rather than after their resource type: laboratory report and result **creatinine**, order **full blood count**, **albumin in 24-hour urine**, **epithelial cells in urine sediment**.

##### Logical Model

* MII_LM_Labor: `experimental` set to `false`. `status` was already `active`.

#### Implementation Guide:

* The guide is published with the IG Publisher instead of Simplifier, bilingual (English default, German translation) and rendered at the module URL.
* New page [Interpretations and Comments](interpretation.md), treating the subject in three parts: the coded interpretation and which codes apply, the comments in `Observation.note`, and the interpretation-affecting properties. It sets out how the narrow FHIR sense of "interpretation" relates to its wider use in the Rili-BÄK and ISO 15189 (both linked), what a coded interpretation is worth for secondary use and where its data quality is limited.
* The module description is split by subject: [Laboratory Timestamps](laboratory-timestamps.md), [Interpretations and Comments](interpretation.md) and [Specimen](specimen.md) are pages of their own.
* The guidelines are cited uniformly across the guide as "Rili-BÄK 2023" and "ISO 15189:2024".
* [Project Context](index.md) no longer describes the Microbiology module as planned — it is published — and now names the findings that belong there rather than in this module, together with how that module binds its examination types to LOINC.

### Version: 2026.0.3

Version 2026.0.3 contains the following changes compared to the previous version 2026.0.2 (for a complete overview of the changes, the [differential view on GitHub](https://github.com/medizininformatik-initiative/kerndatensatzmodul-labor/compare/2026.0.2...2026.0.3) can be used).

Note: Version `2026.0.3` is a package release carrying out technical corrections. The Implementation Guide was not changed in substance.

#### FHIR / Content Changes:

##### General:

* `fix:` Unification of the version designation of the 2026 artifacts on `2026.0.3`; several profiles, extensions, ValueSets and the CapabilityStatement still referenced `2026.0.0`.
* `fix:` Update of the `meta.profile` and `supportedProfile` references from `2026.0.0` to `2026.0.3`.

##### Examples:

* `fix:` Update of the example instances to profile version `2026.0.3`; some profile references still pointed at `2026.0.0`.

#### Implementation Guide:

* Update of the IG version from `2026.0.0` to `2026.0.3` in `package.json`, `sushi-config.yaml`, `qc/custom.rules.yaml` and the FSH rule sets.
* Update of the reference to the current stable version in `README.md` from `2026.0.0` to `2026.0.3`.

### Version: 2026.0.2

Version 2026.0.2 contains the following changes compared to the previous version 2026.0.1 (for a complete overview of the changes, the [differential view on GitHub](https://github.com/medizininformatik-initiative/kerndatensatzmodul-labor/compare/2026.0.1...2026.0.2) can be used).

Note: Version `2026.0.2` is a package release carrying out technical corrections. The Implementation Guide was not changed in substance.

#### FHIR / Content Changes:

##### General:

* `fix:` Correction of the dependency from `hl7.fhir.uv.extensions` to `hl7.fhir.uv.extensions.r4`, so that the R4 extensions in use resolve correctly.
* `fix:` Version specification of the referenced FHIR ValueSet `identifier-type` on `4.0.1`.

##### Examples:

* `fix:` Correction of the LOINC display text in the example `mii-exa-labor-laborwert` ("hohe Vergrößerung").

### Version: 2026.0.1

Version 2026.0.1 contains the following changes compared to the previous version 2026.0.0 (for a complete overview of the changes, the [differential view on GitHub](https://github.com/medizininformatik-initiative/kerndatensatzmodul-labor/compare/2026.0.0...2026.0.1) can be used).

Note: Version `2026.0.1` is a package release carrying out technical corrections. The Implementation Guide was not changed in substance.

#### FHIR / Content Changes:

##### General:

* `fix:` hl7.fhir.uv.extensions was added as a dependency in order to support snapshot generation by Simplifier. MII_PR_Labor_Laboruntersuchung had no snapshot until then.

### Version: 2026.0.0

Version 2026.0.0 contains the following changes compared to the previous version 2025.0.2 (for a complete overview of the changes, the [differential view on GitHub](https://github.com/medizininformatik-initiative/kerndatensatzmodul-labor/compare/2025.0.2...2026.0.0) can be used).

#### FHIR / Content Changes:

##### General:

* All profiles and ValueSets now carry a CC BY 4.0 licence statement
* Extended Must Support (MS) flags on the child elements of complex datatypes, for better interoperability
* Improved multilingual documentation (German/English) with translation inserts for MS elements
* All profiles: coding elements (system, code, display) are now flagged MS
* Update of the IPS dependency to 2.0.0

##### MII_PR_Labor_Laboruntersuchung

* New modifierExtension for interpretation-affecting properties (0..* MS) 
* Allows laboratory tests to be marked with particular properties that affect the interpretation of the laboratory value (for example haemolysis, lipaemia, icterus)
 
* identifier[analyseBefundCode]: Short descriptions and definitions added
* value[x]: Extended Must Support flags 
* valueQuantity.comparator is now MS
* valueQuantity.extension now uses [extension-quantity-translation](http://hl7.org/fhir/StructureDefinition/extension-quantity-translation) instead of the deprecated [pq-translation-ex](http://hl7.org/fhir/StructureDefinition/iso21090-PQ-translation) extension.
 
* effective[x]: Definition made precise as "clinical reference time"

##### MII_PR_Labor_Laboranforderung

* Extended multilingual documentation

##### MII_PR_Labor_Laborbefund

* category: Structural change from 1..1 MS to 1.. MS 
* New slice "lab-category" (1..1 MS) with pattern-based constraints
* Replaces the previous coding slices (loinc-lab, diagnostic-service-sections)
* category[lab-category] combines $loinc#26436-6 and $v2-0074#LAB as a pattern
* category[lab-category].coding requires at least 2 codings (system, code, display as MS)
 

##### Extension - MII_EX_Labor_Interpretationsbeeinflussende_Probeneigenschaft (NEW)

* New modifierExtension for marking interpretation-affecting properties
* Context: Observation
* value[x]: 1.. MS, only Coding permitted
* Bound to the new ValueSet MII_VS_Labor_InterpretationsbeeinflussendeProbeneigenschaften_SNOMEDCT
* Important: Flagged as isModifier, because the interpretation of the measured value is affected

##### Extension - MII_EX_Labor_Quelle_Klinisches_Bezugsdatum

* Context extended: DiagnosticReport.effective.ofType(dateTime) added
* CC BY 4.0 licence added

##### ValueSets

* All ValueSets: CC BY 4.0 licence statement added
* **NEW**: MII_VS_Labor_InterpretationsbeeinflussendeProbeneigenschaften_SNOMEDCT 
* Codes for haemolysis, lipaemia, icterus (SNOMED CT)
 

#### Implementation Guide:

* Improved documentation of the timestamps in the laboratory
* Documentation on interpretation-affecting specimen properties added
* Updated examples for all profiles

