# LOINC Ontology - Analyt PSA - MII IG Laborbefund v2027.0.0-ci

* [**Inhaltsverzeichnis**](toc.md)
* [**Anleitung**](guidance.md)
* [**LOINC-Ontology-ValueSets (Vorschlag)**](loinc-ontology-valuesets.md)
* [**LOINC Ontology - ValueSets je Laborparameter**](loinc-ontology-clinical-tests.md)
* **LOINC Ontology - Analyt PSA**

## LOINC Ontology - Analyt PSA

Diese Seite ist das Review-Material für den Analyten **psa** des [LOINC-Ontology-Vorschlags](loinc-ontology-valuesets.md): der Kandidatenpool, wie ihn die LOINC Ontology 2026-10-21 definiert, und für jeden Laborparameter des Analyten, welche Poolkonzepte die Regel auswählt, welche sie auslässt und an welchem Attribut. Die Methode ist unter [Wie die ValueSets gebaut werden](loinc-ontology-method.md) erklärt.

Kandidatenpool: `<< 363787002 |Observable entity (observable entity)| : << 246093002 |Component (attribute)| = << 102687007 |Prostate specific antigen (substance)|` (37 Konzepte, 37 mit LOINC-Code). Use-Case-ValueSets: [Vollständig](ValueSet-mii-vs-labor-loinc-ontology-psa-complete.md), [Quantitativ](ValueSet-mii-vs-labor-loinc-ontology-psa-quantitative.md), [Konvertierbar](ValueSet-mii-vs-labor-loinc-ontology-psa-convertible.md), [Qualitativ](ValueSet-mii-vs-labor-loinc-ontology-psa-qualitative.md).

### Total PSA in serum, plasma or blood

ValueSet [mii-vs-labor-loinc-ontology-psa-total-standard](ValueSet-mii-vs-labor-loinc-ontology-psa-total-standard.md), Profil [mii-pr-labor-loinc-ontology-psa-total-standard](StructureDefinition-mii-pr-labor-loinc-ontology-psa-total-standard.md). Die Regel wählt 5 der 37 Poolkonzepte aus.

| | |
| :--- | :--- |
| Component | Prostate specific antigen |
| Direct site | `<< Blood specimen minus (<< Cord blood specimen or << Fetal blood specimen or << Dried blood spot specimen)` |
| Property | `<< Mass concentration or << Substance concentration or << Arbitrary concentration` |
| Scale type | `<< Quantitative value` |

#### Enthalten (5)

| | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- |
| 2857-1 | Prostate specific Ag [Mass/volume] in Serum or Plasma | Acellular blood (serum or plasma) specimen | Mass concentration | Quantitative value | – |
| 35741-8 | Prostate specific Ag [Mass/volume] in Serum or Plasma by Detection limit <= 0.01 ng/mL | Acellular blood (serum or plasma) specimen | Mass concentration | Quantitative value | – |
| 83112-3 | Prostate specific Ag [Mass/volume] in Serum or Plasma by Immunoassay | Acellular blood (serum or plasma) specimen | Mass concentration | Quantitative value | Immunoassay technique |
| 19197-3 | Prostate specific Ag [Moles/volume] in Serum or Plasma | Acellular blood (serum or plasma) specimen | Substance concentration | Quantitative value | – |
| 19195-7 | Prostate specific Ag [Units/volume] in Serum or Plasma | Acellular blood (serum or plasma) specimen | Arbitrary concentration | Quantitative value | – |

* **Materialien unter den enthaltenen Codes**: Acellular blood (serum or plasma) specimen (5)
* **Techniken unter den enthaltenen Codes**: Immunoassay technique (1)

#### Aus dem Pool ausgeschlossen (32)

**Ausgeschlossen, weil Direct site nicht passt (9)**

| | | |
| :--- | :--- | :--- |
| 47738-0 | Prostate specific Ag [Mass/volume] in Body fluid | Body fluid specimen |
| 59230-3 | Prostate specific Ag [Mass/volume] in Cerebrospinal Fluid | Cerebrospinal fluid specimen |
| 100716-0 | Prostate specific Ag [Mass/volume] in DBS | Dried blood spot specimen |
| 59223-8 | Prostate specific Ag [Mass/volume] in Peritoneal fluid | Peritoneal fluid specimen |
| 59221-2 | Prostate specific Ag [Mass/volume] in Pleural fluid | Pleural fluid specimen |
| 19199-9 | Prostate specific Ag [Mass/volume] in Semen | Semen sample |
| 34611-4 | Prostate specific Ag [Mass/volume] in Urine | Urine specimen |
| 19200-5 | Prostate specific Ag [Moles/volume] in Semen | Semen sample |
| 19198-1 | Prostate specific Ag [Units/volume] in Semen | Semen sample |

**Ausgeschlossen, weil Component und Direct site nicht passen (7)**

| | | |
| :--- | :--- | :--- |
| 59239-4 | Prostate Specific Ag Free [Mass/volume] in Body fluid | Body fluid specimen |
| 59231-1 | Prostate Specific Ag Free [Mass/volume] in Cerebrospinal Fluid | Cerebrospinal fluid specimen |
| 59224-6 | Prostate Specific Ag Free [Mass/volume] in Peritoneal fluid | Peritoneal fluid specimen |
| 59232-9 | Prostate Specific Ag Free [Mass/volume] in Pleural fluid | Pleural fluid specimen |
| 19205-4 | Prostate Specific Ag Free [Mass/volume] in Semen | Semen sample |
| 19206-2 | Prostate Specific Ag Free [Moles/volume] in Semen | Semen sample |
| 19204-7 | Prostate Specific Ag Free [Units/volume] in Semen | Semen sample |

**Ausgeschlossen, weil Component nicht passt (5)**

| | | | | |
| :--- | :--- | :--- | :--- | :--- |
| 10886-0 | Prostate Specific Ag Free [Mass/volume] in Serum or Plasma | Acellular blood (serum or plasma) specimen | Mass concentration | Quantitative value |
| 83113-1 | Prostate Specific Ag Free [Mass/volume] in Serum or Plasma by Immunoassay | Acellular blood (serum or plasma) specimen | Mass concentration | Quantitative value |
| 19203-9 | Prostate Specific Ag Free [Moles/volume] in Serum or Plasma | Acellular blood (serum or plasma) specimen | Substance concentration | Quantitative value |
| 19201-3 | Prostate Specific Ag Free [Units/volume] in Serum or Plasma | Acellular blood (serum or plasma) specimen | Arbitrary concentration | Quantitative value |
| 33667-7 | Prostate specific Ag.protein bound [Mass/volume] in Serum or Plasma | Acellular blood (serum or plasma) specimen | Mass concentration | Quantitative value |

**Ausgeschlossen, weil Component, Direct site und Property nicht passen (4)**

| | | | |
| :--- | :--- | :--- | :--- |
| 59238-6 | Prostate Specific Ag Free/Prostate specific Ag.total in Body fluid | Body fluid specimen | Mass fraction |
| 59235-2 | Prostate Specific Ag Free/Prostate specific Ag.total in Cerebrospinal Fluid | Cerebrospinal fluid specimen | Mass fraction |
| 59236-0 | Prostate Specific Ag Free/Prostate specific Ag.total in Peritoneal fluid | Peritoneal fluid specimen | Mass fraction |
| 59237-8 | Prostate Specific Ag Free/Prostate specific Ag.total in Pleural fluid | Pleural fluid specimen | Mass fraction |

**Ausgeschlossen, weil Direct site, Property und Scale type nicht passen (2)**

| | | | | |
| :--- | :--- | :--- | :--- | :--- |
| 109230-3 | Prostate specific Ag [Measurement] in Semen | Semen sample | Measurement property | – |
| 10508-0 | Prostate specific Ag [Presence] in Tissue by Immune stain | Tissue specimen | Threshold | Ordinal value |

1 davon haben in diesem Release gar kein Attribut Scale type (der LOINC-System-Part ist noch nicht modelliert), die Regel kann sie also nicht sehen: 109230-3.

**Ausgeschlossen, weil Component, Direct site, Property und Scale type nicht passen (1)**

| | | | | |
| :--- | :--- | :--- | :--- | :--- |
| 109229-5 | Prostate Specific Ag Free [Measurement] in Semen | Semen sample | Measurement property | – |

1 davon haben in diesem Release gar kein Attribut Scale type (der LOINC-System-Part ist noch nicht modelliert), die Regel kann sie also nicht sehen: 109229-5.

**Ausgeschlossen, weil Component und Property nicht passen (1)**

| | | |
| :--- | :--- | :--- |
| 12841-3 | Prostate Specific Ag Free/Prostate specific Ag.total in Serum or Plasma | Mass fraction |

**Ausgeschlossen, weil Component, Property und Scale type nicht passen (1)**

| | | | |
| :--- | :--- | :--- | :--- |
| 110243-3 | Prostate Specific Ag Free [Measurement] in Serum or Plasma | Measurement property | – |

1 davon haben in diesem Release gar kein Attribut Scale type (der LOINC-System-Part ist noch nicht modelliert), die Regel kann sie also nicht sehen: 110243-3.

**Ausgeschlossen, weil Direct site und Property nicht passen (1)**

| | | | |
| :--- | :--- | :--- | :--- |
| 48167-1 | Prostate specific Ag/Creatinine [Mass Ratio] in Urine | Urine specimen | Mass ratio |

**Ausgeschlossen, weil Property und Scale type nicht passen (1)**

| | | | |
| :--- | :--- | :--- | :--- |
| 110671-5 | Prostate specific Ag [Measurement] in Serum or Plasma | Measurement property | – |

1 davon haben in diesem Release gar kein Attribut Scale type (der LOINC-System-Part ist noch nicht modelliert), die Regel kann sie also nicht sehen: 110671-5.

#### Diskussion

* **Fünf Codes.** 2857-1, das immunoassay-spezifische 83112-3 und das ultrasensitive 35741-8 (eine Methode mit niedrigerer Nachweisgrenze, die im Monitoring nach Prostatektomie zählt), dazu die molare Variante 19197-3 und die Variante in arbiträren Einheiten 19195-7, die der erweiterte Property-Block zulässt. Die beiden letzten sind selten, aber dieselbe Messung in anderer Einheit und UCUM-konvertierbar.
* **Der Materialblock ist der gemeinsame Blut-Block.** Er lässt Serum, Plasma und Vollblut zu; ein Vollblut-PSA-Code ist heute nicht modelliert, die Menge ändert sich dadurch nicht. Trockenblut-PSA (100716-0, ein Einsende-Screening-Kit) schließt der Block aus.
* **Proteingebundenes PSA** (33667-7), **freies PSA** und der **Quotient** sind andere Components oder Properties und bleiben draußen; siehe die beiden spezialisierten Tests.

### Free PSA in serum, plasma or blood

ValueSet [mii-vs-labor-loinc-ontology-psa-free-standard](ValueSet-mii-vs-labor-loinc-ontology-psa-free-standard.md), Profil [mii-pr-labor-loinc-ontology-psa-free-standard](StructureDefinition-mii-pr-labor-loinc-ontology-psa-free-standard.md). Die Regel wählt 4 der 37 Poolkonzepte aus.

| | |
| :--- | :--- |
| Component | Free prostate specific antigen |
| Direct site | `<< Blood specimen minus (<< Cord blood specimen or << Fetal blood specimen or << Dried blood spot specimen)` |
| Property | `<< Mass concentration or << Substance concentration or << Arbitrary concentration` |
| Scale type | `<< Quantitative value` |

#### Enthalten (4)

| | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- |
| 10886-0 | Prostate Specific Ag Free [Mass/volume] in Serum or Plasma | Acellular blood (serum or plasma) specimen | Mass concentration | Quantitative value | – |
| 83113-1 | Prostate Specific Ag Free [Mass/volume] in Serum or Plasma by Immunoassay | Acellular blood (serum or plasma) specimen | Mass concentration | Quantitative value | Immunoassay technique |
| 19203-9 | Prostate Specific Ag Free [Moles/volume] in Serum or Plasma | Acellular blood (serum or plasma) specimen | Substance concentration | Quantitative value | – |
| 19201-3 | Prostate Specific Ag Free [Units/volume] in Serum or Plasma | Acellular blood (serum or plasma) specimen | Arbitrary concentration | Quantitative value | – |

* **Materialien unter den enthaltenen Codes**: Acellular blood (serum or plasma) specimen (4)
* **Techniken unter den enthaltenen Codes**: Immunoassay technique (1)

#### Aus dem Pool ausgeschlossen (33)

**Ausgeschlossen, weil Component und Direct site nicht passen (9)**

| | | |
| :--- | :--- | :--- |
| 47738-0 | Prostate specific Ag [Mass/volume] in Body fluid | Body fluid specimen |
| 59230-3 | Prostate specific Ag [Mass/volume] in Cerebrospinal Fluid | Cerebrospinal fluid specimen |
| 100716-0 | Prostate specific Ag [Mass/volume] in DBS | Dried blood spot specimen |
| 59223-8 | Prostate specific Ag [Mass/volume] in Peritoneal fluid | Peritoneal fluid specimen |
| 59221-2 | Prostate specific Ag [Mass/volume] in Pleural fluid | Pleural fluid specimen |
| 19199-9 | Prostate specific Ag [Mass/volume] in Semen | Semen sample |
| 34611-4 | Prostate specific Ag [Mass/volume] in Urine | Urine specimen |
| 19200-5 | Prostate specific Ag [Moles/volume] in Semen | Semen sample |
| 19198-1 | Prostate specific Ag [Units/volume] in Semen | Semen sample |

**Ausgeschlossen, weil Direct site nicht passt (7)**

| | | |
| :--- | :--- | :--- |
| 59239-4 | Prostate Specific Ag Free [Mass/volume] in Body fluid | Body fluid specimen |
| 59231-1 | Prostate Specific Ag Free [Mass/volume] in Cerebrospinal Fluid | Cerebrospinal fluid specimen |
| 59224-6 | Prostate Specific Ag Free [Mass/volume] in Peritoneal fluid | Peritoneal fluid specimen |
| 59232-9 | Prostate Specific Ag Free [Mass/volume] in Pleural fluid | Pleural fluid specimen |
| 19205-4 | Prostate Specific Ag Free [Mass/volume] in Semen | Semen sample |
| 19206-2 | Prostate Specific Ag Free [Moles/volume] in Semen | Semen sample |
| 19204-7 | Prostate Specific Ag Free [Units/volume] in Semen | Semen sample |

**Ausgeschlossen, weil Component nicht passt (6)**

| | | | | |
| :--- | :--- | :--- | :--- | :--- |
| 2857-1 | Prostate specific Ag [Mass/volume] in Serum or Plasma | Acellular blood (serum or plasma) specimen | Mass concentration | Quantitative value |
| 35741-8 | Prostate specific Ag [Mass/volume] in Serum or Plasma by Detection limit <= 0.01 ng/mL | Acellular blood (serum or plasma) specimen | Mass concentration | Quantitative value |
| 83112-3 | Prostate specific Ag [Mass/volume] in Serum or Plasma by Immunoassay | Acellular blood (serum or plasma) specimen | Mass concentration | Quantitative value |
| 19197-3 | Prostate specific Ag [Moles/volume] in Serum or Plasma | Acellular blood (serum or plasma) specimen | Substance concentration | Quantitative value |
| 19195-7 | Prostate specific Ag [Units/volume] in Serum or Plasma | Acellular blood (serum or plasma) specimen | Arbitrary concentration | Quantitative value |
| 33667-7 | Prostate specific Ag.protein bound [Mass/volume] in Serum or Plasma | Acellular blood (serum or plasma) specimen | Mass concentration | Quantitative value |

**Ausgeschlossen, weil Direct site und Property nicht passen (4)**

| | | | |
| :--- | :--- | :--- | :--- |
| 59238-6 | Prostate Specific Ag Free/Prostate specific Ag.total in Body fluid | Body fluid specimen | Mass fraction |
| 59235-2 | Prostate Specific Ag Free/Prostate specific Ag.total in Cerebrospinal Fluid | Cerebrospinal fluid specimen | Mass fraction |
| 59236-0 | Prostate Specific Ag Free/Prostate specific Ag.total in Peritoneal fluid | Peritoneal fluid specimen | Mass fraction |
| 59237-8 | Prostate Specific Ag Free/Prostate specific Ag.total in Pleural fluid | Pleural fluid specimen | Mass fraction |

**Ausgeschlossen, weil Component, Direct site, Property und Scale type nicht passen (2)**

| | | | | |
| :--- | :--- | :--- | :--- | :--- |
| 109230-3 | Prostate specific Ag [Measurement] in Semen | Semen sample | Measurement property | – |
| 10508-0 | Prostate specific Ag [Presence] in Tissue by Immune stain | Tissue specimen | Threshold | Ordinal value |

1 davon haben in diesem Release gar kein Attribut Scale type (der LOINC-System-Part ist noch nicht modelliert), die Regel kann sie also nicht sehen: 109230-3.

**Ausgeschlossen, weil Component, Direct site und Property nicht passen (1)**

| | | | |
| :--- | :--- | :--- | :--- |
| 48167-1 | Prostate specific Ag/Creatinine [Mass Ratio] in Urine | Urine specimen | Mass ratio |

**Ausgeschlossen, weil Component, Property und Scale type nicht passen (1)**

| | | | |
| :--- | :--- | :--- | :--- |
| 110671-5 | Prostate specific Ag [Measurement] in Serum or Plasma | Measurement property | – |

1 davon haben in diesem Release gar kein Attribut Scale type (der LOINC-System-Part ist noch nicht modelliert), die Regel kann sie also nicht sehen: 110671-5.

**Ausgeschlossen, weil Direct site, Property und Scale type nicht passen (1)**

| | | | | |
| :--- | :--- | :--- | :--- | :--- |
| 109229-5 | Prostate Specific Ag Free [Measurement] in Semen | Semen sample | Measurement property | – |

1 davon haben in diesem Release gar kein Attribut Scale type (der LOINC-System-Part ist noch nicht modelliert), die Regel kann sie also nicht sehen: 109229-5.

**Ausgeschlossen, weil Property nicht passt (1)**

| | | |
| :--- | :--- | :--- |
| 12841-3 | Prostate Specific Ag Free/Prostate specific Ag.total in Serum or Plasma | Mass fraction |

**Ausgeschlossen, weil Property und Scale type nicht passen (1)**

| | | | |
| :--- | :--- | :--- | :--- |
| 110243-3 | Prostate Specific Ag Free [Measurement] in Serum or Plasma | Measurement property | – |

1 davon haben in diesem Release gar kein Attribut Scale type (der LOINC-System-Part ist noch nicht modelliert), die Regel kann sie also nicht sehen: 110243-3.

#### Diskussion

* **Vier Codes** (10886-0, 83113-1, das molare 19203-9 und 19201-3 in arbiträren Einheiten). Freies PSA ist in SNOMED CT eine eigene Substanz, die Trennung vom Gesamt-PSA ist sauber.
* **Der Quotient** (12841-3) ist über die Property ausgeschlossen und hat einen eigenen Test.

### %Free PSA (free/total ratio)

ValueSet [mii-vs-labor-loinc-ontology-psa-free-total-ratio](ValueSet-mii-vs-labor-loinc-ontology-psa-free-total-ratio.md), Profil [mii-pr-labor-loinc-ontology-psa-free-total-ratio](StructureDefinition-mii-pr-labor-loinc-ontology-psa-free-total-ratio.md). Die Regel wählt 1 der 37 Poolkonzepte aus.

| | |
| :--- | :--- |
| Component | `<< Prostate specific antigen` |
| Direct site | `<< Acellular blood (serum or plasma) specimen` |
| Property | `<< Ratio or << Mass fraction` |

#### Enthalten (1)

| | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- |
| 12841-3 | Prostate Specific Ag Free/Prostate specific Ag.total in Serum or Plasma | Acellular blood (serum or plasma) specimen | Mass fraction | Quantitative value | – |

* **Materialien unter den enthaltenen Codes**: Acellular blood (serum or plasma) specimen (1)
* **Techniken unter den enthaltenen Codes**: (keine)

#### Aus dem Pool ausgeschlossen (36)

**Ausgeschlossen, weil Direct site und Property nicht passen (19)**

| | | | |
| :--- | :--- | :--- | :--- |
| 59239-4 | Prostate Specific Ag Free [Mass/volume] in Body fluid | Body fluid specimen | Mass concentration |
| 59231-1 | Prostate Specific Ag Free [Mass/volume] in Cerebrospinal Fluid | Cerebrospinal fluid specimen | Mass concentration |
| 59224-6 | Prostate Specific Ag Free [Mass/volume] in Peritoneal fluid | Peritoneal fluid specimen | Mass concentration |
| 59232-9 | Prostate Specific Ag Free [Mass/volume] in Pleural fluid | Pleural fluid specimen | Mass concentration |
| 19205-4 | Prostate Specific Ag Free [Mass/volume] in Semen | Semen sample | Mass concentration |
| 109229-5 | Prostate Specific Ag Free [Measurement] in Semen | Semen sample | Measurement property |
| 19206-2 | Prostate Specific Ag Free [Moles/volume] in Semen | Semen sample | Substance concentration |
| 19204-7 | Prostate Specific Ag Free [Units/volume] in Semen | Semen sample | Arbitrary concentration |
| 47738-0 | Prostate specific Ag [Mass/volume] in Body fluid | Body fluid specimen | Mass concentration |
| 59230-3 | Prostate specific Ag [Mass/volume] in Cerebrospinal Fluid | Cerebrospinal fluid specimen | Mass concentration |
| 100716-0 | Prostate specific Ag [Mass/volume] in DBS | Dried blood spot specimen | Mass concentration |
| 59223-8 | Prostate specific Ag [Mass/volume] in Peritoneal fluid | Peritoneal fluid specimen | Mass concentration |
| 59221-2 | Prostate specific Ag [Mass/volume] in Pleural fluid | Pleural fluid specimen | Mass concentration |
| 19199-9 | Prostate specific Ag [Mass/volume] in Semen | Semen sample | Mass concentration |
| 34611-4 | Prostate specific Ag [Mass/volume] in Urine | Urine specimen | Mass concentration |
| 109230-3 | Prostate specific Ag [Measurement] in Semen | Semen sample | Measurement property |
| 19200-5 | Prostate specific Ag [Moles/volume] in Semen | Semen sample | Substance concentration |
| 10508-0 | Prostate specific Ag [Presence] in Tissue by Immune stain | Tissue specimen | Threshold |
| 19198-1 | Prostate specific Ag [Units/volume] in Semen | Semen sample | Arbitrary concentration |

**Ausgeschlossen, weil Property nicht passt (12)**

| | | |
| :--- | :--- | :--- |
| 10886-0 | Prostate Specific Ag Free [Mass/volume] in Serum or Plasma | Mass concentration |
| 83113-1 | Prostate Specific Ag Free [Mass/volume] in Serum or Plasma by Immunoassay | Mass concentration |
| 110243-3 | Prostate Specific Ag Free [Measurement] in Serum or Plasma | Measurement property |
| 19203-9 | Prostate Specific Ag Free [Moles/volume] in Serum or Plasma | Substance concentration |
| 19201-3 | Prostate Specific Ag Free [Units/volume] in Serum or Plasma | Arbitrary concentration |
| 2857-1 | Prostate specific Ag [Mass/volume] in Serum or Plasma | Mass concentration |
| 35741-8 | Prostate specific Ag [Mass/volume] in Serum or Plasma by Detection limit <= 0.01 ng/mL | Mass concentration |
| 83112-3 | Prostate specific Ag [Mass/volume] in Serum or Plasma by Immunoassay | Mass concentration |
| 110671-5 | Prostate specific Ag [Measurement] in Serum or Plasma | Measurement property |
| 19197-3 | Prostate specific Ag [Moles/volume] in Serum or Plasma | Substance concentration |
| 19195-7 | Prostate specific Ag [Units/volume] in Serum or Plasma | Arbitrary concentration |
| 33667-7 | Prostate specific Ag.protein bound [Mass/volume] in Serum or Plasma | Mass concentration |

**Ausgeschlossen, weil Direct site nicht passt (5)**

| | | |
| :--- | :--- | :--- |
| 59238-6 | Prostate Specific Ag Free/Prostate specific Ag.total in Body fluid | Body fluid specimen |
| 59235-2 | Prostate Specific Ag Free/Prostate specific Ag.total in Cerebrospinal Fluid | Cerebrospinal fluid specimen |
| 59236-0 | Prostate Specific Ag Free/Prostate specific Ag.total in Peritoneal fluid | Peritoneal fluid specimen |
| 59237-8 | Prostate Specific Ag Free/Prostate specific Ag.total in Pleural fluid | Pleural fluid specimen |
| 48167-1 | Prostate specific Ag/Creatinine [Mass Ratio] in Urine | Urine specimen |

#### Diskussion

* **Ein Code** (12841-3). Die Regel lässt Ratio oder Mass fraction zu, damit eine LOINC-Änderung des Property-Typs die Menge nicht stillschweigend leert.
* **Wertetyp.** Der Quotient wird als Prozentwert berichtet; das Profil legt Quantity fest, mit `%` als erwarteter Einheit.

### Der Pool und seine Use-Case-Gruppen

Eine Zeile je Poolkonzept mit den Attributen, die die Klassifikation nutzt; die Gruppe ist das Use-Case-ValueSet, in dem das Konzept landet.

| | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| 59239-4 | Prostate Specific Ag Free [Mass/volume] in Body fluid | Mass concentration | Quantitative value | Body fluid specimen | Konvertierbar | Quantitative Skala + Konzentrations-Property |
| 59231-1 | Prostate Specific Ag Free [Mass/volume] in Cerebrospinal Fluid | Mass concentration | Quantitative value | Cerebrospinal fluid specimen | Konvertierbar | Quantitative Skala + Konzentrations-Property |
| 59224-6 | Prostate Specific Ag Free [Mass/volume] in Peritoneal fluid | Mass concentration | Quantitative value | Peritoneal fluid specimen | Konvertierbar | Quantitative Skala + Konzentrations-Property |
| 59232-9 | Prostate Specific Ag Free [Mass/volume] in Pleural fluid | Mass concentration | Quantitative value | Pleural fluid specimen | Konvertierbar | Quantitative Skala + Konzentrations-Property |
| 19205-4 | Prostate Specific Ag Free [Mass/volume] in Semen | Mass concentration | Quantitative value | Semen sample | Konvertierbar | Quantitative Skala + Konzentrations-Property |
| 10886-0 | Prostate Specific Ag Free [Mass/volume] in Serum or Plasma | Mass concentration | Quantitative value | Acellular blood (serum or plasma) specimen | Konvertierbar | Quantitative Skala + Konzentrations-Property |
| 83113-1 | Prostate Specific Ag Free [Mass/volume] in Serum or Plasma by Immunoassay | Mass concentration | Quantitative value | Acellular blood (serum or plasma) specimen | Konvertierbar | Quantitative Skala + Konzentrations-Property |
| 19206-2 | Prostate Specific Ag Free [Moles/volume] in Semen | Substance concentration | Quantitative value | Semen sample | Konvertierbar | Quantitative Skala + Konzentrations-Property |
| 19203-9 | Prostate Specific Ag Free [Moles/volume] in Serum or Plasma | Substance concentration | Quantitative value | Acellular blood (serum or plasma) specimen | Konvertierbar | Quantitative Skala + Konzentrations-Property |
| 19204-7 | Prostate Specific Ag Free [Units/volume] in Semen | Arbitrary concentration | Quantitative value | Semen sample | Konvertierbar | Quantitative Skala + Konzentrations-Property |
| 19201-3 | Prostate Specific Ag Free [Units/volume] in Serum or Plasma | Arbitrary concentration | Quantitative value | Acellular blood (serum or plasma) specimen | Konvertierbar | Quantitative Skala + Konzentrations-Property |
| 47738-0 | Prostate specific Ag [Mass/volume] in Body fluid | Mass concentration | Quantitative value | Body fluid specimen | Konvertierbar | Quantitative Skala + Konzentrations-Property |
| 59230-3 | Prostate specific Ag [Mass/volume] in Cerebrospinal Fluid | Mass concentration | Quantitative value | Cerebrospinal fluid specimen | Konvertierbar | Quantitative Skala + Konzentrations-Property |
| 100716-0 | Prostate specific Ag [Mass/volume] in DBS | Mass concentration | Quantitative value | Dried blood spot specimen | Konvertierbar | Quantitative Skala + Konzentrations-Property |
| 59223-8 | Prostate specific Ag [Mass/volume] in Peritoneal fluid | Mass concentration | Quantitative value | Peritoneal fluid specimen | Konvertierbar | Quantitative Skala + Konzentrations-Property |
| 59221-2 | Prostate specific Ag [Mass/volume] in Pleural fluid | Mass concentration | Quantitative value | Pleural fluid specimen | Konvertierbar | Quantitative Skala + Konzentrations-Property |
| 19199-9 | Prostate specific Ag [Mass/volume] in Semen | Mass concentration | Quantitative value | Semen sample | Konvertierbar | Quantitative Skala + Konzentrations-Property |
| 2857-1 | Prostate specific Ag [Mass/volume] in Serum or Plasma | Mass concentration | Quantitative value | Acellular blood (serum or plasma) specimen | Konvertierbar | Quantitative Skala + Konzentrations-Property |
| 35741-8 | Prostate specific Ag [Mass/volume] in Serum or Plasma by Detection limit <= 0.01 ng/mL | Mass concentration | Quantitative value | Acellular blood (serum or plasma) specimen | Konvertierbar | Quantitative Skala + Konzentrations-Property |
| 83112-3 | Prostate specific Ag [Mass/volume] in Serum or Plasma by Immunoassay | Mass concentration | Quantitative value | Acellular blood (serum or plasma) specimen | Konvertierbar | Quantitative Skala + Konzentrations-Property |
| 34611-4 | Prostate specific Ag [Mass/volume] in Urine | Mass concentration | Quantitative value | Urine specimen | Konvertierbar | Quantitative Skala + Konzentrations-Property |
| 19200-5 | Prostate specific Ag [Moles/volume] in Semen | Substance concentration | Quantitative value | Semen sample | Konvertierbar | Quantitative Skala + Konzentrations-Property |
| 19197-3 | Prostate specific Ag [Moles/volume] in Serum or Plasma | Substance concentration | Quantitative value | Acellular blood (serum or plasma) specimen | Konvertierbar | Quantitative Skala + Konzentrations-Property |
| 19198-1 | Prostate specific Ag [Units/volume] in Semen | Arbitrary concentration | Quantitative value | Semen sample | Konvertierbar | Quantitative Skala + Konzentrations-Property |
| 19195-7 | Prostate specific Ag [Units/volume] in Serum or Plasma | Arbitrary concentration | Quantitative value | Acellular blood (serum or plasma) specimen | Konvertierbar | Quantitative Skala + Konzentrations-Property |
| 33667-7 | Prostate specific Ag.protein bound [Mass/volume] in Serum or Plasma | Mass concentration | Quantitative value | Acellular blood (serum or plasma) specimen | Konvertierbar | Quantitative Skala + Konzentrations-Property |
| 109229-5 | Prostate Specific Ag Free [Measurement] in Semen | Measurement property | – | Semen sample | Quantitativ | Mess-Property, keine Skala asserted (generisch) |
| 110243-3 | Prostate Specific Ag Free [Measurement] in Serum or Plasma | Measurement property | – | Acellular blood (serum or plasma) specimen | Quantitativ | Mess-Property, keine Skala asserted (generisch) |
| 59238-6 | Prostate Specific Ag Free/Prostate specific Ag.total in Body fluid | Mass fraction | Quantitative value | Body fluid specimen | Quantitativ | Quantitative Skala |
| 59235-2 | Prostate Specific Ag Free/Prostate specific Ag.total in Cerebrospinal Fluid | Mass fraction | Quantitative value | Cerebrospinal fluid specimen | Quantitativ | Quantitative Skala |
| 59236-0 | Prostate Specific Ag Free/Prostate specific Ag.total in Peritoneal fluid | Mass fraction | Quantitative value | Peritoneal fluid specimen | Quantitativ | Quantitative Skala |
| 59237-8 | Prostate Specific Ag Free/Prostate specific Ag.total in Pleural fluid | Mass fraction | Quantitative value | Pleural fluid specimen | Quantitativ | Quantitative Skala |
| 12841-3 | Prostate Specific Ag Free/Prostate specific Ag.total in Serum or Plasma | Mass fraction | Quantitative value | Acellular blood (serum or plasma) specimen | Quantitativ | Quantitative Skala |
| 109230-3 | Prostate specific Ag [Measurement] in Semen | Measurement property | – | Semen sample | Quantitativ | Mess-Property, keine Skala asserted (generisch) |
| 110671-5 | Prostate specific Ag [Measurement] in Serum or Plasma | Measurement property | – | Acellular blood (serum or plasma) specimen | Quantitativ | Mess-Property, keine Skala asserted (generisch) |
| 48167-1 | Prostate specific Ag/Creatinine [Mass Ratio] in Urine | Mass ratio | Quantitative value | Urine specimen | Quantitativ | Quantitative Skala |
| 10508-0 | Prostate specific Ag [Presence] in Tissue by Immune stain | Threshold | Ordinal value | Tissue specimen | Qualitativ | Ordinale/nominale Skala → qualitativ |

### LOINC-Terme des Analyten außerhalb des Pools

Recall-Prüfung gegen LOINC 2.83 selbst: 38 Laborterme passen auf das LOINC-Muster des Analyten (Component ~ ^Prostate specific Ag); 36 davon liegen im Pool, 2 nicht. Ein Term liegt außerhalb des Pools, wenn die LOINC Ontology ihn mit einer anderen Component modelliert oder gar nicht. Jeder davon ist entweder ein hinzunehmender Modellierungsunterschied oder ein Change Request an die LOINC Ontology.

| | | | |
| :--- | :--- | :--- | :--- |
| 72576-2 | Prostate Specific Ag Free/Prostate specific Ag.total [Pure mass fraction] in Serum or Plasma | MFr.DF | Ser/Plas |
| 53764-7 | Prostate specific Ag panel - Serum or Plasma | - | Ser/Plas |

