# Beispiele - MII IG Laborbefund v2027.0.0-ci

* [**Inhaltsverzeichnis**](toc.md)
* **Beispiele**

## Beispiele

 Diese Seite enthält Übersetzungen aus der Originalsprache, in der der Leitfaden verfasst wurde. Informationen zu diesen Übersetzungen und Anweisungen zum Abgeben von Feedback zu den Übersetzungen finden Sie [hier](translationinfo.md). 

* [Laborbefund: Nierendiagnostik](DiagnosticReport-mii-exa-labor-laborbefund.md)
* [Anforderung: Nierendiagnostik](ServiceRequest-mii-exa-labor-laboranforderung.md)
* [Laborergebnis: Kreatinin](Observation-mii-exa-labor-laborwert.md)
* [Laborergebnis: Kalium aus hämolytischer Probe](Observation-mii-exa-labor-laborwert-haemolyse.md)
* [Laborergebnis: Kreatinin im Spontanurin ohne Wert (Data Absent Reason)](Observation-mii-exa-labor-laborwert-data-absent-reason.md)
* [Laborergebnis: Epithelzellen im Urinsediment (Bereich)](Observation-mii-exa-labor-laborwert-range.md)
* [Laborergebnis: Albumin im 24-Stunden-Urin](Observation-mii-exa-labor-laborwert-ratio.md)
* [Laborergebnis: Hämoglobin (LOINC-Ontology-Profil, Vorschlag)](Observation-mii-exa-labor-loinc-ontology-hemoglobin.md)

