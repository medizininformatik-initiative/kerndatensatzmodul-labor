# LOINC Ontology - Wie die ValueSets gebaut werden - MII IG Laborbefund v2027.0.0-ci

* [**Inhaltsverzeichnis**](toc.md)
* [**Anleitung**](guidance.md)
* [**LOINC-Ontology-ValueSets (Vorschlag)**](loinc-ontology-valuesets.md)
* **LOINC Ontology - Wie die ValueSets gebaut werden**

## LOINC Ontology - Wie die ValueSets gebaut werden

Diese Seite erklärt, wie jedes ValueSet des [LOINC-Ontology-Vorschlags](loinc-ontology-valuesets.md) konstruiert ist, damit eine Leserin eine Regel prüfen, ein ValueSet auf einem Terminologieserver expandieren und die Artefakte für ein neues Release neu erzeugen kann.

### Die LOINC Ontology in einem Absatz

Die [LOINC Ontology](https://loincsnomed.org) wird gemeinsam vom Regenstrief Institute und SNOMED International veröffentlicht. Sie bildet LOINC-Laborterme als SNOMED-CT-Konzepte in einem Extension-Modul ab (Modul-ID `11010000107`), eingehängt unter **Observable entity**. Jedes Konzept trägt seinen LOINC-Code als alternativen Identifikator und ist mit denselben Attributen modelliert, aus denen ein LOINC-Term besteht. Weil die Konzepte in SNOMED CT liegen, kann die SNOMED Expression Constraint Language (ECL) sie über Attributwerte selektieren, einschließlich der Subtyp-Hierarchien des Werts.

| | | | |
| :--- | :--- | :--- | :--- |
| Component | `246093002` | Component | Hemoglobin (substance) |
| Property | `370130000` | Property | Mass concentration |
| Scale type | `370132008` | Scale | Quantitative value |
| Direct site | `704327008` | System | Blood specimen |
| Technique | `246501002` | Method | (keine) |
| Time aspect | `370134009` | Time | Single point in time |

### Aufbau einer Regel

Die Regel für den klinischen Test **Hämoglobinkonzentration im Blut** lautet:

```
<< 363787002 |Observable entity| :
    246093002 |Component|   = 38082009 |Hemoglobin (substance)|,
 << 704327008 |Direct site| = << 119297000 |Blood specimen|,
 << 370130000 |Property|    = << 118539007 |Mass concentration|,
 << 370132008 |Scale type|  = << 30766002 |Quantitative value|

```

Zu lesen als: jedes Observable, dessen Component genau Hemoglobin ist, dessen Material Blut oder ein Subtyp von Blut ist (venös, arteriell, kapillär), dessen Property Massenkonzentration oder ein Subtyp ist und dessen Skala quantitativ ist. `<<` bedeutet „dieses Konzept und alle seine Nachfahren", `<` „nur die Nachfahren"; ohne beides muss der Wert exakt passen. Die Wahl zwischen beidem ist eine sichtbar gemachte klinische Entscheidung: `<< 38082009` würde zusätzlich HbA1c und die Hämoglobin-Varianten einbeziehen, was für einen Hämoglobin-**Pool** gewollt ist, für den Routinetest Hämoglobin aber nicht.

Dieselbe Regel, zerlegt wie in den Tabellen der folgenden Seiten:

| | | |
| :--- | :--- | :--- |
| Component | Hemoglobin | genau diese Substanz |
| Direct site | `<< Blood specimen` | dieses Material oder ein Subtyp |
| Property | `<< Mass concentration` | diese Property oder ein Subtyp |
| Scale type | `<< Quantitative value` | diese Skala oder ein Subtyp |

### Die drei Teile jedes ValueSets

Jedes ValueSet dieses Vorschlags hat dasselbe `compose`:

1. **LOINC-Aufzählung.**Die LOINC-Codes aller Konzepte, die die Regel selektiert, als`include`auf`http://loinc.org`mit der LOINC-Version des Moduls. Diesen Teil kann jeder FHIR-Validator und jeder Terminologieserver heute nutzen.
1. **Observables ohne LOINC-Code.**Die LOINC Ontology enthält auch Observables, für die noch kein LOINC-Code existiert. Sie sind als SNOMED-CT-Codes aufgeführt, damit das ValueSet vollständig ist und ein Standort sieht, wo ein LOINC-Antrag aussteht.
1. **Die Regel.**Die ECL als intensionales`include`auf`http://snomed.info/sct`mit`filter.property = constraint`, gepinnt auf das Release`http://snomed.info/sct/11010000107/version/20261021`. Sie dokumentiert, warum die Codes aus Teil 1 enthalten sind, und sie ist der Teil, der sich neu erzeugt.

Teil 1 und 2 sind die Aufzählung von Teil 3 zum genannten Release. Sie sind keine unabhängigen Quellen.

### Expandieren und validieren

* Auf einem Terminologieserver, der das Release der LOINC Ontology hält (etwa Snowstorm mit geladener LOINC-Extension oder der LOINC-Ontology-Browser), expandieren alle drei Teile, und die Expansion entspricht der Aufzählung.
* Auf einem Server ohne LOINC Ontology, etwa dem HL7-Server des IG-Builds, lassen sich die SNOMED-CT-Includes nicht auflösen. Der QA-Report des Builds zeigt das als Warnung für jedes ECL-Include und als Fehler für jeden aufgezählten SNOMED-CT-Code ohne LOINC-Code (derzeit in fünf ValueSets: die **vollständigen** und **qualitativen** Mengen von Erythrozyten und Hämatokrit sowie die **qualitative** Menge der Leukozyten, je ein Konzept). Die LOINC-Aufzählung expandiert trotzdem, und die Validierung eines `Observation.code` mit LOINC-Code funktioniert wie gewohnt.
* Ein Validator, der `Observation.code` gegen ein abgeleitetes Profil prüft, braucht nur die LOINC-Aufzählung.
* **Die CI des Moduls** validiert über einen Proxy gegen den MII-Terminologieserver. In den Läufen vom Oktober 2026 hat dieser Server jeden aufgezählten LOINC- und SNOMED-CT-Code zurückgewiesen, auch auf `master` (die 18 LOINC-Codes des ValueSets Laborbereich werden dort als ungültig gemeldet). Die Branch-Preview zeigt deshalb je aufgezähltem LOINC-Code dieses Vorschlags einen Fehler. Diese Zahlen messen die Terminologie-Konfiguration der CI, nicht die ValueSets; der Build mit dem öffentlichen HL7-Server meldet nur die oben genannten LOINC-Ontology-Fehler.

### Versionen und Neuerzeugung

Die Artefakte sind auf **LOINC Ontology 2026-10-21** gepinnt. Die LOINC Ontology erscheint in regelmäßigen Releases; das Modul pinnt für seine eigenen ValueSets LOINC 2.82. Ein Code, den LOINC zwischen beiden Ständen eingeführt oder abgekündigt hat, ist ein Review-Punkt, kein Versagen der Methode. Für ein neues Release führt der Generator jede Regel erneut aus, listet die Konzepte, die in jedem ValueSet hinzugekommen oder weggefallen sind, und schreibt diese Seiten neu. Ein Release kann auch die Attribute selbst neu modellieren: Zwischen 2026-03-21 und 2026-10-21 hat die LOINC Ontology über 10.000 Nachweis-Observables von der Property `Presence` (705057003) auf `Threshold (property)` (118589004, ein Subtyp von Measurement property) umgestellt und von „Presence of …" in „Threshold presence of …" umbenannt. Die Nitrit-Regel auf diesem Branch selektiert deshalb `<< 118589004 |Threshold (property)|` statt `<< 705057003 |Presence|`; ihre LOINC-Aufzählung hat sich nicht geändert. Die alte Regel hätte ein leeres ValueSet geliefert, genau die Art von Fehler, die eine Neuerzeugung sichtbar macht. Der Differenzbericht zwischen zwei Releases ist mit dem Generator in [loincsnomed-lab-concepts](https://github.com/medizininformatik-initiative/loincsnomed-lab-concepts) veröffentlicht.

### Die Review-Tabellen lesen

Zu jedem ValueSet veröffentlicht der Generator außerdem eine Tabelle mit einer Zeile je Konzept: LOINC-Code, SCTID, Fully Specified Name, die Use-Case-Gruppe, in die es klassifiziert wurde, und die Attributwerte, die zur Klassifikation geführt haben. Diese Tabellen sind der Ort, einen einzelnen Code anzufechten; die Regel ist der Ort, eine ganze Menge anzufechten.

