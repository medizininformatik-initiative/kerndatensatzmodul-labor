# MII VS Labor LOINC Ontology Mch Qualitative - MII IG Laborbefund v2027.0.0-ci

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MII VS Labor LOINC Ontology Mch Qualitative**

## ValueSet: MII VS Labor LOINC Ontology Mch Qualitative (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:https://www.medizininformatik-initiative.de/fhir/core/modul-labor/ValueSet/mii-vs-labor-loinc-ontology-mch-qualitative | *Version*:2027.0.0-ci |
| Draft as of 2026-10-20 | *Computable Name*:MII_VS_Labor_LOINC_Ontology_Mch_Qualitative |
| **Copyright/Legal**: This material includes SNOMED Clinical Terms® (SNOMED CT®) which is used by permission of SNOMED International. All rights reserved. SNOMED CT®, was originally created by The College of American Pathologists. SNOMED and SNOMED CT are registered trademarks of SNOMED International. Implementers of these artefacts must have the appropriate SNOMED CT Affiliate license. | |

 
Proposal: use-case ValueSet 'Qualitative (ordinal / nominal / presence)' for the analyte mch (Ordinal or Nominal scale, OR Presence property. Presence/absence, +/-, dipstick-style results.). Candidate pool = `<< 363787002 |Observable entity (observable entity)| : << 246093002 |Component (attribute)| = << 38082009 |Hemoglobin (substance)|` against the LOINC Ontology 2026-03-21. 114 concepts (114 with LOINC). Classification of the pool by Scale type and Property; the rule is stated above. 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "mii-vs-labor-loinc-ontology-mch-qualitative",
  "meta" : {
    "extension" : [{
      "extension" : [{
        "url" : "packageId",
        "valueId" : "de.medizininformatikinitiative.kerndatensatz.laborbefund"
      },
      {
        "url" : "version",
        "valueString" : "2027.0.0-ci"
      },
      {
        "url" : "uri",
        "valueUri" : "https://www.medizininformatik-initiative.de/fhir/core/modul-labor"
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/package-source"
    }],
    "profile" : ["http://hl7.org/fhir/StructureDefinition/shareablevalueset",
    "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-shareablevalueset",
    "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-publishablevalueset",
    "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-computablevalueset"]
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-versionAlgorithm",
    "valueCoding" : {
      "system" : "http://hl7.org/fhir/version-algorithm",
      "code" : "semver",
      "display" : "SemVer"
    }
  },
  {
    "url" : "https://www.medizininformatik-initiative.de/fhir/modul-meta/StructureDefinition/mii-ex-meta-license-codeable",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://hl7.org/fhir/spdx-license",
        "code" : "CC-BY-4.0",
        "display" : "Creative Commons Attribution 4.0 International"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-knowledgeCapability",
    "valueCode" : "shareable"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-knowledgeCapability",
    "valueCode" : "publishable"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-knowledgeCapability",
    "valueCode" : "computable"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-versionPolicy",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/artifact-version-policy-codes",
        "code" : "package",
        "display" : "Package"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-topic",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://ncicb.nci.nih.gov/xml/owl/EVS/Thesaurus.owl",
        "code" : "C36292"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-topic",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://ncicb.nci.nih.gov/xml/owl/EVS/Thesaurus.owl",
        "code" : "C25294"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-author",
    "valueContactDetail" : {
      "telecom" : [{
        "system" : "email",
        "value" : "pw@gefyra.de"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-editor",
    "valueContactDetail" : {
      "name" : "Taskforce Core Data Set"
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-reviewer",
    "valueContactDetail" : {
      "name" : "Interoperability Working Group",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.medizininformatik-initiative.de/en/collaboration/interoperability-working-group"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-reviewer",
    "valueContactDetail" : {
      "name" : "National Steering Committee",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.medizininformatik-initiative.de/en/collaboration/national-steering-committee"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-endorser",
    "valueContactDetail" : {
      "name" : "Interoperability Working Group",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.medizininformatik-initiative.de/en/collaboration/interoperability-working-group"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-endorser",
    "valueContactDetail" : {
      "name" : "National Steering Committee",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.medizininformatik-initiative.de/en/collaboration/national-steering-committee"
      }]
    }
  }],
  "url" : "https://www.medizininformatik-initiative.de/fhir/core/modul-labor/ValueSet/mii-vs-labor-loinc-ontology-mch-qualitative",
  "version" : "2027.0.0-ci",
  "name" : "MII_VS_Labor_LOINC_Ontology_Mch_Qualitative",
  "title" : "MII VS Labor LOINC Ontology Mch Qualitative",
  "status" : "draft",
  "experimental" : true,
  "date" : "2026-10-20",
  "publisher" : "Medizininformatik Initiative",
  "contact" : [{
    "name" : "Medizininformatik Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de"
    }]
  }],
  "description" : "Proposal: use-case ValueSet 'Qualitative (ordinal / nominal / presence)' for the analyte mch (Ordinal or Nominal scale, OR Presence property. Presence/absence, +/-, dipstick-style results.). Candidate pool = `<< 363787002 |Observable entity (observable entity)| : << 246093002 |Component (attribute)| = << 38082009 |Hemoglobin (substance)|` against the LOINC Ontology 2026-03-21. 114 concepts (114 with LOINC). Classification of the pool by Scale type and Property; the rule is stated above.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "purpose" : "Guidance for use-case-driven aggregation of laboratory results in secondary use; accompanies ballot comments on 2027.0.0-ballot. Generated, not hand-curated.",
  "copyright" : "This material includes SNOMED Clinical Terms® (SNOMED CT®) which is used by permission of SNOMED International. All rights reserved. SNOMED CT®, was originally created by The College of American Pathologists. SNOMED and SNOMED CT are registered trademarks of SNOMED International. Implementers of these artefacts must have the appropriate SNOMED CT Affiliate license.",
  "compose" : {
    "include" : [{
      "system" : "http://loinc.org",
      "version" : "2.82",
      "concept" : [{
        "code" : "32160-4"
      },
      {
        "code" : "45208-6"
      },
      {
        "code" : "28559-3"
      },
      {
        "code" : "27345-8"
      },
      {
        "code" : "4556-7"
      },
      {
        "code" : "4557-5"
      },
      {
        "code" : "4558-3"
      },
      {
        "code" : "4559-1"
      },
      {
        "code" : "55783-5"
      },
      {
        "code" : "4560-9"
      },
      {
        "code" : "40720-5"
      },
      {
        "code" : "40545-6"
      },
      {
        "code" : "4564-1"
      },
      {
        "code" : "4565-8"
      },
      {
        "code" : "4566-6"
      },
      {
        "code" : "4567-4"
      },
      {
        "code" : "4568-2"
      },
      {
        "code" : "4572-4"
      },
      {
        "code" : "40546-4"
      },
      {
        "code" : "28067-7"
      },
      {
        "code" : "4579-9"
      },
      {
        "code" : "4632-6"
      },
      {
        "code" : "32140-6"
      },
      {
        "code" : "18277-4"
      },
      {
        "code" : "18278-2"
      },
      {
        "code" : "30074-9"
      },
      {
        "code" : "40721-3"
      },
      {
        "code" : "4631-8"
      },
      {
        "code" : "28006-5"
      },
      {
        "code" : "4577-3"
      },
      {
        "code" : "4581-5"
      },
      {
        "code" : "4583-1"
      },
      {
        "code" : "4584-9"
      },
      {
        "code" : "4585-6"
      },
      {
        "code" : "4586-4"
      },
      {
        "code" : "40547-2"
      },
      {
        "code" : "17871-5"
      },
      {
        "code" : "4589-8"
      },
      {
        "code" : "4590-6"
      },
      {
        "code" : "4591-4"
      },
      {
        "code" : "4592-2"
      },
      {
        "code" : "4593-0"
      },
      {
        "code" : "4594-8"
      },
      {
        "code" : "4598-9"
      },
      {
        "code" : "4599-7"
      },
      {
        "code" : "717-9"
      },
      {
        "code" : "33517-4"
      },
      {
        "code" : "48035-0"
      },
      {
        "code" : "2334-1"
      },
      {
        "code" : "42909-2"
      },
      {
        "code" : "42910-0"
      },
      {
        "code" : "42911-8"
      },
      {
        "code" : "34618-9"
      },
      {
        "code" : "50017-3"
      },
      {
        "code" : "2335-8"
      },
      {
        "code" : "14563-1"
      },
      {
        "code" : "14564-9"
      },
      {
        "code" : "14565-6"
      },
      {
        "code" : "12503-9"
      },
      {
        "code" : "12504-7"
      },
      {
        "code" : "27401-9"
      },
      {
        "code" : "27925-7"
      },
      {
        "code" : "27926-5"
      },
      {
        "code" : "80372-6"
      },
      {
        "code" : "104738-0"
      },
      {
        "code" : "29771-3"
      },
      {
        "code" : "57905-2"
      },
      {
        "code" : "56490-6"
      },
      {
        "code" : "56491-4"
      },
      {
        "code" : "725-2"
      },
      {
        "code" : "57751-0"
      },
      {
        "code" : "5794-3"
      },
      {
        "code" : "48047-5"
      },
      {
        "code" : "42912-6"
      },
      {
        "code" : "42913-4"
      },
      {
        "code" : "4595-5"
      },
      {
        "code" : "4596-3"
      },
      {
        "code" : "4597-1"
      },
      {
        "code" : "4600-3"
      },
      {
        "code" : "4601-1"
      },
      {
        "code" : "4602-9"
      },
      {
        "code" : "4603-7"
      },
      {
        "code" : "4604-5"
      },
      {
        "code" : "4605-2"
      },
      {
        "code" : "53224-2"
      },
      {
        "code" : "4606-0"
      },
      {
        "code" : "4607-8"
      },
      {
        "code" : "4608-6"
      },
      {
        "code" : "4610-2"
      },
      {
        "code" : "4611-0"
      },
      {
        "code" : "4612-8"
      },
      {
        "code" : "4613-6"
      },
      {
        "code" : "4614-4"
      },
      {
        "code" : "4615-1"
      },
      {
        "code" : "4616-9"
      },
      {
        "code" : "4617-7"
      },
      {
        "code" : "4618-5"
      },
      {
        "code" : "4619-3"
      },
      {
        "code" : "34663-5"
      },
      {
        "code" : "4621-9"
      },
      {
        "code" : "4622-7"
      },
      {
        "code" : "4623-5"
      },
      {
        "code" : "6864-3"
      },
      {
        "code" : "4626-8"
      },
      {
        "code" : "4627-6"
      },
      {
        "code" : "4628-4"
      },
      {
        "code" : "4629-2"
      },
      {
        "code" : "4630-0"
      },
      {
        "code" : "2613-8"
      },
      {
        "code" : "2619-5"
      },
      {
        "code" : "4684-7"
      },
      {
        "code" : "53117-8"
      },
      {
        "code" : "4639-1"
      },
      {
        "code" : "41619-8"
      }]
    }]
  }
}

```
