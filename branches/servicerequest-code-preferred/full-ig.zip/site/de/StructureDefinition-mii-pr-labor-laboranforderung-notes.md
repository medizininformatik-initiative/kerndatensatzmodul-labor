### Hinweise zu den Elementen

| FHIR Element | Erklärung |
|--------------|-----------|
| Patient.id      | Must-support, jedoch optional        |
| Patient.meta       | Must-support, jedoch optional         |
| ServiceRequest.identifier       |  Anforderungsnummer der gewünschten Untersuchung, min. eindeutig durch System und Value identifiziert. Dient zur Verknüfung des Labor-Systems und dem anfordernden System.|
| ServiceRequest.status       | Fixed value, da nur finale Anforderungen abgebildet werden sollen. |
| ServiceRequest.intent       | Fixed value, ServiceRequest repräsentiert immer die Anforderung der Diagnostik.|
| ServiceRequest.category       | Festes Coding `laboratory` (observation-category), weitere Codings erlaubt.|
| ServiceRequest.code       | Vorzugsweise ein LOINC-Code für Anforderungen aus [MII VS Labor Order Codes](ValueSet-mii-vs-labor-order-codes.html) (Binding preferred); andere Codes sind zulässig. Falls angeforderte Laborparameter nicht kodiert vorliegen -> CodeableConcept.text |
| ServiceRequest.subject       |  Bezug zum Patienten muss stets gegeben sein|
| ServiceRequest.authoredOn       |  Erstelldatum der Anforderung, falls nicht vorhanden Eingangsdatum der Anforderung        |
| ServiceRequest.specimen       | Optionale Referenz, zukünftige Spezifikationen weiterer Kerndatensatzmodule können diesbezüglich Vorgaben ausgestalten.|

### Zuordnung zum logischen Modell

| FHIR Element | Logischer Datensatz |
|--------------|-----------|
| ServiceRequest.identifier       |  Laborbefund.Laboranforderung.Identifikation        |
| ServiceRequest.status       | Laborbefund.Laboranforderung.Status         |
| ServiceRequest.code       | Laborbefund.Laboranforderung.Laborparameter         |
| ServiceRequest.authoredOn       |  Laborbefund.Laboranforderung.Anforderungsdatum          |
| ServiceRequest.specimen       |  Laborbefund.Laboranforderung.Probenmaterial         |
