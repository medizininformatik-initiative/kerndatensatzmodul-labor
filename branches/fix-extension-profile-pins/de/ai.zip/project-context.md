# Projektkontext - MII IG Laborbefund v2027.0.0-ballot.rc1

* [**Inhaltsverzeichnis**](toc.md)
* [**Anleitung**](guidance.md)
* **Projektkontext**

## Projektkontext

 Diese Seite enthält Übersetzungen aus der Originalsprache, in der der Leitfaden verfasst wurde. Informationen zu diesen Übersetzungen und Anweisungen zum Abgeben von Feedback zu den Übersetzungen finden Sie [hier](translationinfo.md). 

### Kontext im Gesamtprojekt / Bezüge zu anderen Modulen

Das Modul LABOR bildet Laborbefunde ab, die typischerweise in einem Zentrallabor eines Klinikums erhoben werden. Diese Befunde spielen in den meisten Use Cases der MII eine zentrale Rolle:

* Laborbefunde aus Routineuntersuchungen sind essentiell für Diagnosefindung und Therapieüberwachung bei den meisten Erkrankungen
* Laboruntersuchungen sind ein wichtiger Bestandteil vieler klinischer Studien

Für Laborbefunde, die sich in erster Linie mit dem Nachweis infektiologischer Erreger (Mikrobiologie, Virologie) befassen, ist ein gesondertes, aber eng verwandtes Modul geplant, in dem mit SNOMED CT die einzelnen Erreger abgebildet werden können. Außerdem gibt es für Befunde aus der Pathologie ein eigenes Modul.

Ein Laborbefund ist dabei immer der PERSON zugeordnet, von welcher die Probe entnommen wurde. Wenn diese Probe in einer Biobank für weitere Untersuchungen verwahrt wird, kann diese Probe mit den Profilen im Modul BIOBANK abgebildet werden. Die Ergebnisse aus einem Laborbefund können als einzelne Elemente in verschiedenen anderen Modulen, z.B. zur Tumordokumentation wieder eingebunden sein.

