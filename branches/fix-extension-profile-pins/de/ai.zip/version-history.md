# Versionierung - MII IG Laborbefund v2027.0.0-ballot.rc1

* [**Inhaltsverzeichnis**](toc.md)
* **Versionierung**

## Versionierung

 Diese Seite enthält Übersetzungen aus der Originalsprache, in der der Leitfaden verfasst wurde. Informationen zu diesen Übersetzungen und Anweisungen zum Abgeben von Feedback zu den Übersetzungen finden Sie [hier](translationinfo.md). 

Das Modul folgt der MII-Kalenderversionierung. Die hier publizierte Version ist `2027.0.0-ballot.rc1`, der Ballot-Kandidat für 2027.0.0; Einzelheiten stehen im [Änderungsprotokoll](changes.md).

