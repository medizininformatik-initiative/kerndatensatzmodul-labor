### Notes on the elements

| FHIR element | Explanation |
|--------------|-----------|
| Patient.id | Must Support, but optional |
| Patient.meta | Must Support, but optional |
| Observation.identifier | The Observation must be unambiguously identifiable; no requirements are made on the coding, preference: 'LOINC CODE_report number' |
| Observation.status | Final and preliminary results are permitted. A test that was not performed is cancelled, with dataAbsentReason. |
| Observation.category | LOINC and HL7 code, further codings permitted. </br>No requirement is made for laboratory groups/areas, since no cross-site agreement exists for these. </br>For laboratory groups, reference is made to the ValueSet [Laboratory area](ValueSet-mii-vs-labor-laborbereich.html). It may be used optionally. |
| Observation.code | [IPS LOINC ValueSet](http://hl7.org/fhir/uv/ips/ValueSet/results-laboratory-pathology-observations-uv-ips); in some cases it makes sense to record the local identifier code in addition to the LOINC (see Terminology > LOINC coding at a site). |
| Observation.subject | A reference to the patient must always be present. |
| Observation.effective[x] | Test time (clinical reference time) of the laboratory test. Usually a dateTime (see constraint mii-lab-1). If the specimen was collected over an interval, for example 24-hour urine, effectivePeriod states the collection period. The clinical reference time of the laboratory test should be derived from the laboratory receipt time (redundant with Specimen.receivedTime), the collection time (redundant with Specimen.collection.collected[x]) or the clinical reference time of the laboratory report (DiagnosticReport.effective[x]). These values come closest to the point in time at which the measured property in the specimen (e.g. the concentration of an analyte) presumably corresponded to that property in the patient. The extension QuelleKlinischesBezugsdatum is to be used to specify whether the value is a collection time or a specimen receipt time. |
| Observation.valueQuantity | UCUM quantity — mandatory, no deviating coding permitted. |
| Observation.valueRatio | Only for results that are a genuine ratio and cannot be stated as a quantity, typically titres outside microbiology (for example ANA 1:160): numerator 1, denominator the dilution step, as in the titre profile of the Microbiology module. Rates such as an excretion per 24 hours are stated as valueQuantity with a composed UCUM unit (for example mg/(24.h)). The search parameter value-quantity does not cover a ratio; for that, the CapabilityStatement lists the value-ratio search parameters of the Meta module (SHOULD). |
| Observation.valueCodeableConcept | For coding semiquantitative results (0 to +++), see the ValueSet 'Semi_quantitative_Laborergebnisse' |
| Observation.note | Optional text |
| Observation.method | Coded method that was used to measure Observation.value. Only to be populated if the method is not implicitly contained in Observation.code (in the LOINC code, for instance). No coding recommendation is given, because this information is usually not available in structured form in the source systems. |
| Observation.specimen | Optional reference; specimen information is held in the FHIR profile Specimen (Specimen Bioprobe Core) of the Biobank extension module. |
| Observation.referenceRange | Should — where available — be coded as high, low (SimpleQuantity). Otherwise, by way of exception, via referenceRange.text. |
| Observation.component | Observation.hasMember is to be preferred in clinical chemistry (more fitting semantics). The element is permitted for harmonisation with genetic findings. |

### Mapping to the logical model

| FHIR element | Logical dataset |
|--------------|-----------|
| Observation.identifier | Laborbefund.Laboruntersuchung.Identifikation |
| Observation.status | Laborbefund.Laboruntersuchung.Status |
| Observation.category | Laborbefund.Laboruntersuchung.Bereich |
| Observation.category | Laborbefund.Laboruntersuchung.Gruppe |
| Observation.code | Laborbefund.Laboruntersuchung.Laborparameter |
| Observation.effective[x] | Laborbefund.Laboruntersuchung.Untersuchungszeitpunkt |
| Observation.issued | Laborbefund.Laboruntersuchung.Dokumentationsdatum |
| Observation.valueQuantity | Laborbefund.Laboruntersuchung.Messwert |
| Observation.interpretation | Laborbefund.Laboruntersuchung.Interpretation |
| Observation.note | Laborbefund.Laboruntersuchung.Kommentar |
| Observation.method | Laborbefund.Laboruntersuchung.Untersuchungsmethode |
| Observation.referenceRange | Laborbefund.Laboruntersuchung.Referenzbereich |
