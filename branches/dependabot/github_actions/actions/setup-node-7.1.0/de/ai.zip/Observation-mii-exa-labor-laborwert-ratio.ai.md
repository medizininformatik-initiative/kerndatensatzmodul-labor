# Laboratory result: albumin in 24-hour urine - MII IG Laborbefund v2027.0.0-ci

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **Laboratory result: albumin in 24-hour urine**

## Beispiel Observation: Laboratory result: albumin in 24-hour urine

-------

**German**

-------

Profile: [MII PR Labor Laboruntersuchung](StructureDefinition-mii-pr-labor-laboruntersuchung.md) version: 2027.0.0-ci

Security Label: [test health data (Details: ActReason code HTEST = 'test health data')](http://terminology.hl7.org/7.2.0/CodeSystem-v3-ActReason.html)

**identifier**: Observation Instance Identifier/1755-8_1234567890

**basedOn**: [ServiceRequest Nierendiagnostik](ServiceRequest-mii-exa-labor-laboranforderung.md)

**status**: Final

**category**: Laboratory

**code**: Albumin (24H U) [Mass/Time]

**subject**: [Anonymous Patient (no stated gender), DoB Unknown ( https://example.org/fhir/sid/test-patients#111)](Patient-111.md)

**encounter**: [Encounter: identifier = https://example.org/fhir/sid/test-encounters#555; status = finished; class = inpatient encounter (ActCode#IMP)](Encounter-555.md)

**effective**: 2018-11-19 08:00:00+0100 --> 2018-11-20 08:00:00+0100

**issued**: 2018-11-20 14:30:00+0100

**performer**: [Zentrallabor Beispielklinikum](Organization-7772.md)

**value**: 15 mg/24h (Details: UCUM codemg/(24.h) = 'mg/(24.h)')

**specimen**: [Specimen: identifier = https://example.org/fhir/sid/test-specimens#4998; type = ; receivedTime = 2018-11-20 08:40:00+0100](Specimen-4998.md)



## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "mii-exa-labor-laborwert-ratio",
  "meta" : {
    "profile" : ["https://www.medizininformatik-initiative.de/fhir/core/modul-labor/StructureDefinition/ObservationLab|2027.0.0-ci"],
    "security" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
      "code" : "HTEST",
      "display" : "test health data"
    }]
  },
  "identifier" : [{
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
        "code" : "OBI"
      }]
    },
    "system" : "https://example.org/fhir/sid/test-lab-results",
    "value" : "1755-8_1234567890",
    "assigner" : {
      "identifier" : {
        "system" : "https://www.medizininformatik-initiative.de/fhir/core/CodeSystem/core-location-identifier",
        "value" : "DIZ-ID"
      }
    }
  }],
  "basedOn" : [{
    "reference" : "ServiceRequest/mii-exa-labor-laboranforderung"
  }],
  "status" : "final",
  "category" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
      "code" : "laboratory",
      "display" : "Laboratory"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.82",
      "code" : "26436-6",
      "display" : "Laboratory studies (set)"
    }]
  }],
  "code" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "version" : "2.82",
      "code" : "1755-8",
      "display" : "Albumin [Mass/time] in 24 hour Urine"
    }],
    "text" : "Albumin (24H U) [Mass/Time]"
  },
  "subject" : {
    "reference" : "Patient/111"
  },
  "encounter" : {
    "reference" : "Encounter/555"
  },
  "effectivePeriod" : {
    "extension" : [{
      "url" : "https://www.medizininformatik-initiative.de/fhir/core/modul-labor/StructureDefinition/QuelleKlinischesBezugsdatum",
      "valueCoding" : {
        "system" : "http://snomed.info/sct",
        "version" : "http://snomed.info/sct/900000000000207008/version/20260701",
        "code" : "399445004",
        "display" : "Specimen collection date"
      }
    }],
    "start" : "2018-11-19T08:00:00+01:00",
    "end" : "2018-11-20T08:00:00+01:00"
  },
  "issued" : "2018-11-20T14:30:00+01:00",
  "performer" : [{
    "reference" : "Organization/7772",
    "identifier" : {
      "system" : "https://example.org/fhir/sid/test-organizations",
      "value" : "7772"
    },
    "display" : "Zentrallabor Beispielklinikum"
  }],
  "valueQuantity" : {
    "value" : 15,
    "unit" : "mg/24h",
    "system" : "http://unitsofmeasure.org",
    "code" : "mg/(24.h)"
  },
  "specimen" : {
    "reference" : "Specimen/4998"
  }
}

```
