# Sicherheit und Datenschutz - MII IG Laborbefund v2027.0.0-ballot

* [**Inhaltsverzeichnis**](toc.md)
* **Sicherheit und Datenschutz**

## Sicherheit und Datenschutz

 Diese Seite enthält Übersetzungen aus der Originalsprache, in der der Leitfaden verfasst wurde. Informationen zu diesen Übersetzungen und Anweisungen zum Abgeben von Feedback zu den Übersetzungen finden Sie [hier](translationinfo.md). 

Das Modul definiert keine eigenen Sicherheits- oder Datenschutzanforderungen; es gelten die MII-weiten Vorgaben.

