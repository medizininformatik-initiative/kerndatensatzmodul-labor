# Sicherheit und Datenschutz - MII IG Laborbefund v2027.0.0-ballot.rc3

* [**Inhaltsverzeichnis**](toc.md)
* **Sicherheit und Datenschutz**

## Sicherheit und Datenschutz

 Diese Seite enthält Übersetzungen aus der Originalsprache, in der der Leitfaden verfasst wurde. Informationen zu diesen Übersetzungen und Anweisungen zum Abgeben von Feedback zu den Übersetzungen finden Sie [hier](translationinfo.md). 

Der Ausgangsleitfaden enthält keine modulspezifischen Sicherheits- oder Datenschutzanforderungen. Für Labordaten gelten die organisatorischen Vorgaben zu Zugriffsschutz, Protokollierung, Einwilligung und Datenschutz sowie die MII-weiten Sicherheitsvorgaben.

