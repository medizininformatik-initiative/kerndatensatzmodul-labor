# Guidance for Implementers - MII IG Laborbefund v2027.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Guidance**](guidance.md)
* **Guidance for Implementers**

## Guidance for Implementers

This page collects what is needed to implement the Laboratory Report module in FHIR-based systems.

### Understanding the Requirements

**1. Logical Models — Business Requirements**

The [Logical Models](logical-models.md) carry the business and clinical requirements, independently of the FHIR profiles:

* **Laboratory report** — identification, status, clinical reference date, documentation date
* **Specimen** — identification, collection and laboratory receipt time, specimen type, body site
* **Laboratory test** — parameter, result and interpretation, reference range, method
* **Laboratory order** — identification, status, request date

Their data types and cardinalities are not normative; the profiles define the binding requirements.

**2. UML Diagrams — Data Relationships**

The [UML Diagrams](uml-diagrams.md) illustrate the relationships between the elements and the references between the resources.

### Conformance

The conformance rules apply across the whole Core Dataset and are maintained by the Meta module, not repeated here:

* [Conformance](https://github.com/medizininformatik-initiative/kerndatensatz-meta/wiki/Conformance) — the rules as a whole
* [General Requirements](https://github.com/medizininformatik-initiative/kerndatensatz-meta/wiki/Conformance#anforderungsdokumentation)
* [Must Support](https://github.com/medizininformatik-initiative/kerndatensatz-meta/wiki/Conformance#must-support-ms)
* [Handling Missing Data](https://github.com/medizininformatik-initiative/kerndatensatz-meta/wiki/Conformance#fehlende-daten)
* [Security and Privacy](security-and-privacy.md) — module-specific notes

### Technical Artifacts

* [Profiles](profiles.md) — the four profiles with their constraints, plus the per-resource pages explaining them
* [Extensions](extensions.md) — source of the clinical reference date, interpretation-affecting property
* [Value Sets](value-sets.md) — the nine value sets the module defines
* [Terminology](terminology.md) — LOINC coding, the MII-300 subset, units and UCUM
* [Capability Statements](capability-statements.md) — the REST requirements, including interactions and search parameters
* [Examples](examples.md) — sample resources
* [ImplementationGuide resource](ImplementationGuide-mii-ig-labor.md) — the package versions this guide actually resolves to, the global profiles and the expansion parameters

### Domain Guidance

Three subjects are described separately for implementation:

* [Laboratory Timestamps](laboratory-timestamps.md) — laboratory data carries several timestamps whose meaning differs: collection time, laboratory receipt time, request time, and the documentation times of result and report. The clinical reference time is the one that makes measurements comparable over time; the mapping and the reasoning are there.
* [Interpretations and Comments](interpretation.md) — the coded assessment of a result and the ValueSet provided for it.
* [Specimen](specimen.md) — the representation of specimen material via the Biobank module.

### Getting Started with Implementation

**Downloads**

The [Downloads](downloads.md) page provides the FHIR package for validation, the examples in JSON and XML, and the machine-readable ImplementationGuide resource.

**Terminology Service**

For value set expansion and code validation, use the MII terminology server:

* **URL:** [https://www.ontoserver.mii-termserv.de/](https://www.ontoserver.mii-termserv.de/)

The versions this guide is pinned to are declared in its expansion parameters; expanding against a different version can yield a different set of codes.

**Validation**

Validate against the FHIR package with the [FHIR Validator](https://confluence.hl7.org/spaces/FHIR/pages/35718580/Using+the+FHIR+Validator).

