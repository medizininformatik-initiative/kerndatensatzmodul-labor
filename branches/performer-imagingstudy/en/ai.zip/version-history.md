# Versioning - MII IG Laborbefund v2027.0.0-ballot

* [**Table of Contents**](toc.md)
* **Versioning**

## Versioning

The module follows MII calendar versioning. The version published here is `2027.0.0-ballot`, the ballot candidate for 2027.0.0; detailed changes are recorded in the [changelog](changes.md).

