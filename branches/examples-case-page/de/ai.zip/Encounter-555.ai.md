# mii-exa-labor-encounter - MII IG Laborbefund v2027.0.0-ci

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **mii-exa-labor-encounter**

## Beispiel Encounter: mii-exa-labor-encounter

-------

**German**

-------

**identifier**: `https://example.org/fhir/sid/test-encounters`/555

**status**: Finished

**class**: [ActCode: IMP](http://terminology.hl7.org/7.2.0/CodeSystem-v3-ActCode.html#v3-ActCode-IMP) (inpatient encounter)

**subject**: [Anonymous Patient (no stated gender), DoB Unknown ( https://example.org/fhir/sid/test-patients#111)](Patient-111.md)



## Resource Content

```json
{
  "resourceType" : "Encounter",
  "id" : "555",
  "identifier" : [{
    "system" : "https://example.org/fhir/sid/test-encounters",
    "value" : "555"
  }],
  "status" : "finished",
  "class" : {
    "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
    "code" : "IMP",
    "display" : "inpatient encounter"
  },
  "subject" : {
    "reference" : "Patient/111"
  }
}

```
