### Hinweise zu den Elementen

| FHIR Element | Erklärung |
|--------------|-----------|
| Patient.id      | Must-support, jedoch optional        |
| Patient.meta       | Must-support, jedoch optional         |
| Observation.identifier       | Observation muss eindeutig identifizierbar sein, keine Vorgaben zur Kodierung, Präferenz: 'LOINC CODE_Befundnummer'|
| Observation.status       |  Finale & vorläufige Ergebnisse sind zulässig. Eine nicht durchgeführte Untersuchung hat den Status cancelled, mit dataAbsentReason. |
| Observation.category       | Verpflichtende Kategorie `laboratory` (observation-category); weitere Codings und weitere Kategorien erlaubt, z. B. LOINC 26436-6. </br>Keine Vorgabe für Laborgruppen/-bereiche, da hier keine standortübergreifende Abstimmung erfolgt. </br>Für Laborgruppen wird auf das ValueSet [Laborbereich](ValueSet-mii-vs-labor-laborbereich.html) verwiesen. Dieses kann optional verwendet werden.|
| Observation.code       | [IPS LOINC ValueSet](http://hl7.org/fhir/uv/ips/ValueSet/results-laboratory-pathology-observations-uv-ips); Zum Teil kann es Sinn machen, zusätzlich zum LOINC den lokalen Bezeichner-Code zu hinterlegen (siehe Terminologien > LOINC-Kodierung am Standort).        |
| Observation.subject       | Patientenbezug muss stets gegeben sein. |
| Observation.effective[x] | Untersuchungszeitpunkt (Klinischer Bezugszeitpunkt) der Laboruntersuchung. In der Regel ein dateTime (siehe Constraint mii-lab-1). Wurde die Probe über einen Zeitraum gewonnen, z. B. 24-Stunden-Sammelurin, gibt effectivePeriod den Sammelzeitraum an. Der klinische Bezugszeitpunkt der Laboruntersuchung sollte auf Basis des Laboreingangszeitpunkts (redundant zu Specimen.receivedTime) oder Entnahmezeitpunkt (redundant zu Specimen.collection.collected[x]) oder des klinischen Bezugszeitpunkt des Laborberichts (DiagnosticReport.effective[x]) ermittelt werden. Diese Werte entsprechen am ehestem dem Zeitpunkt zudem die gemessene Eigenschaft im Probenmaterial (e.g. Analytkonzentration) mutmaßlich der Eigenschaft im Patienten entsprach. Per extension QuelleKlinischesBezugsdatum soll spezifiziert werden, ob es sich um einen Entnahme- oder Probeneingangszeitpunkt handelt. |
| Observation.valueQuantity      | UCUM Quantity - verpflichtend, keine abweichende Kodierung zugelassen.|
| Observation.valueRatio | Nur für Ergebnisse, die ein echtes Verhältnis sind und sich nicht als Menge angeben lassen, typischerweise Titer außerhalb der Mikrobiologie (z. B. ANA 1:160): Zähler 1, Nenner die Verdünnungsstufe, wie im Titer-Profil des Moduls Mikrobiologie. Raten wie eine Ausscheidung pro 24 Stunden werden als valueQuantity mit zusammengesetzter UCUM-Einheit angegeben (z. B. mg/(24.h)). Der Suchparameter value-quantity erfasst kein Verhältnis; dafür führt das CapabilityStatement die value-ratio-Suchparameter des Moduls Meta (SHOULD). |
|Observation.valueCodeableConcept| Für die Kodierung von semi-quantitativen (0 - +++) Ergebnissen, siehe ValueSet 'Semi_quantitative_Laborergebnisse'|
| Observation.note      | Optionaler Text |
| Observation.method      | Kodierte Methode zur welche verwendet wurde zur Messung von Observation.value. Nur zu befüllen falls Methode nicht implizit in Observation.code enthalten ist (z.B. im LOINC Code). Es wird keine Codierungsempfehlung angegeben, da diese Information meist nicht strukturiert vorliegt in den Quellsystemen.|
| Observation.specimen      | Optionale Referenz; Probeninformationen sind im FHIR-Profil Specimen (Specimen Bioprobe Core) des Erweiterungsmoduls Biobank hinterlegt. |
| Observation.referenceRange      | Sollte - falls vorhanden - als high, low (SimpleQuantity) kodiert werden. Abweichend ansonsten per referenceRange.text.|
| Observation.component | Observation.hasMember ist im Bereich der klinischen Chemie zu bevorzugen (passendere Semantik). Element ist für die Harmonisierung mit Genetischen Befunden erlaubt. |

### Zuordnung zum logischen Modell

| FHIR Element | Logischer Datensatz |
|--------------|-----------|
| Observation.identifier      | Laborbefund.Laboruntersuchung.Identifikation         |
| Observation.status       | Laborbefund.Laboruntersuchung.Status         |
| Observation.category      | Laborbefund.Laboruntersuchung.Bereich |
| Observation.category      | Laborbefund.Laboruntersuchung.Gruppe|
| Observation.code      | Laborbefund.Laboruntersuchung.Laborparameter|
| Observation.effective[x]       | Laborbefund.Laboruntersuchung.Untersuchungszeitpunkt|
| Observation.issued       | Laborbefund.Laboruntersuchung.Dokumentationsdatum |
| Observation.valueQuantity       | Laborbefund.Laboruntersuchung.Messwert |
| Observation.interpretation       | Laborbefund.Laboruntersuchung.Interpretation |
| Observation.note       | Laborbefund.Laboruntersuchung.Kommentar |
| Observation.method       | Laborbefund.Laboruntersuchung.Untersuchungsmethode|
| Observation.referenceRange       | Laborbefund.Laboruntersuchung.Referenzbereich |
