# de.medizininformatikinitiative.kerndatensatz.labor#2027.0.0: MII IG Laborbefund(de)

## Pages

* [Startseite](index.md)
* [Beispiele](examples.md)
* [Laboruntersuchung](observation.md)
* [Datensätze und Beschreibungen](datasets-and-descriptions.md)
* [Terminologie](terminology.md)
* [Konformität](conformance.md)
* [Umgang mit fehlenden Daten](missing-data.md)
* [Laboranforderung](service-request.md)
* [Versionierung](version-history.md)
* [Extensions](extensions.md)
* [Hinweise für Forschende](researcher-guidance.md)
* [Metadatenübersicht](metadata.md)
* [Hinweise für Implementierende](implementer-guidance.md)
* [Must Support](must-support.md)
* [Artefaktübersicht](artifacts.md)
* [Zeitpunkte im Labor](laboratory-timestamps.md)
* [Probenmaterial](specimen.md)
* [Referenzen](references.md)
* [Übersetzungsinformationen](translationinfo.md)
* [Projektkontext](project-context.md)
* [Änderungen](changes.md)
* [Logische Modelle](logical-models.md)
* [Anleitung](guidance.md)
* [Allgemeine Anforderungen](general-requirements.md)
* [Downloads](downloads.md)
* [Sicherheit und Datenschutz](security-and-privacy.md)
* [CapabilityStatements](capability-statements.md)
* [Suchparameter und Operationen](search-parameters-and-operations.md)
* [UML-Diagramm](uml-diagrams.md)
* [Laborbefund](diagnostic-report.md)
* [Profile und Extensions](profiles-and-extensions.md)

## Resources

### ValueSets

* [MII VS Labor Identifier Type Codes](ValueSet-mii-vs-labor-identifier-type-codes.md)
* [MII VS Labor Interpretationsbeeinflussende Eigenschaften SNOMEDCT](ValueSet-mii-vs-labor-interpretation-eigenschaften-snomedct.md)
* [MII VS Labor Laborbereich](ValueSet-mii-vs-labor-laborbereich.md)
* [MII VS Labor Laborergbenis Semiquantitativ](ValueSet-mii-vs-labor-laborergbenis-semiquantitativ.md)
* [MII VS Labor Laborergebnis Codiert](ValueSet-mii-vs-labor-laborergebnis-codiert.md)
* [MII VS Labor Laborergebnis Qualitativ](ValueSet-mii-vs-labor-laborergebnis-qualitativ.md)
* [MII VS Labor Order Codes](ValueSet-mii-vs-labor-order-codes.md)
* [MII VS Labor Quelle klinisches Bezugsdatum](ValueSet-mii-vs-labor-quelle-klinisches-bezugsdatum.md)

### Logicals

* [MII LM Labor](StructureDefinition-mii-lm-labor.md)

### Resource Profiles

* [MII PR Labor Laboranforderung](StructureDefinition-mii-pr-labor-laboranforderung.md)
* [MII PR Labor Laborbefund](StructureDefinition-mii-pr-labor-laborbefund.md)
* [MII PR Labor Laboruntersuchung](StructureDefinition-mii-pr-labor-laboruntersuchung.md)

### Extensions

* [MII EX Labor Interpretationsbeeinflussende Eigenschaft](StructureDefinition-mii-ex-labor-interpretationsbeeinflussende-eigenschaft.md)
* [MII EX Labor Quelle Klinisches Bezugsdatum](StructureDefinition-mii-ex-labor-quelle-klinisches-bezugsdatum.md)

### CapabilityStatements

* [MII CPS Labor CapabilityStatement](CapabilityStatement-mii-cps-labor-capabilitystatement.md)

### ImplementationGuides

* [MII IG Laborbefund](ImplementationGuide-mii-ig-labor.md)

### Parameters

* [mii-param-labor-manifest](Parameters-mii-param-labor-manifest.md)

### Examples

* [mii-exa-labor-laborbefund (DiagnosticReport)](DiagnosticReport-mii-exa-labor-laborbefund.md)
* [555 (Encounter)](Encounter-555.md)
* [mii-exa-labor-laborwert-data-absent-reason (Observation)](Observation-mii-exa-labor-laborwert-data-absent-reason.md)
* [mii-exa-labor-laborwert-range (Observation)](Observation-mii-exa-labor-laborwert-range.md)
* [mii-exa-labor-laborwert-ratio (Observation)](Observation-mii-exa-labor-laborwert-ratio.md)
* [mii-exa-labor-laborwert (Observation)](Observation-mii-exa-labor-laborwert.md)
* [Zentrallabor Beispielklinikum (Organization)](Organization-7772.md)
* [111 (Patient)](Patient-111.md)
* [mii-exa-labor-laboranforderung (ServiceRequest)](ServiceRequest-mii-exa-labor-laboranforderung.md)
* [4999 (Specimen)](Specimen-4999.md)
