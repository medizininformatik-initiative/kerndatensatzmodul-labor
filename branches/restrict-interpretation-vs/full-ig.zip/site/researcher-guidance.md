# Guidance for Researchers

Laboratory tests are central to most medical diagnoses. Preliminary results can matter for time-critical applications, while final results are normally used for patient care and research. The central document represented by this module is a medical laboratory report. Because the module is broadly applicable, the source guide does not prescribe consortium-specific scenarios.
