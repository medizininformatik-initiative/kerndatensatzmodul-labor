# Profiles and Extensions - MII IG Laborbefund v2027.0.0

* [**Table of Contents**](toc.md)
* **Profiles and Extensions**

## Profiles and Extensions

# Profiles and Extensions

Where possible, the MII core data set specifications build on international standards and terminology, especially the [International Patient Summary](http://hl7.org/fhir/uv/ips/history.html). German healthcare requirements are represented using the [German base profiles](https://simplifier.net/guide/basisprofil-de-r4/home).

The module's elements and use-case-specific constraints are defined by FHIR StructureDefinitions. The reasons for relevant constraints are described on the following pages:

* [Laboratory report (DiagnosticReport)](diagnostic-report.md)
* [Laboratory test (Observation)](observation.md)
* [Laboratory request (ServiceRequest)](service-request.md)
* [Specimen](specimen.md)
* [Laboratory extensions](extensions.md)

Required and Must Support elements follow the applicable [IPS Must Support rules](https://build.fhir.org/ig/HL7/fhir-ips/design.html#must-support).

