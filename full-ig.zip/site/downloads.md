This page links the downloadable artifacts of this implementation guide.

### Package File

The package contains every value set, profile and extension of this version, together with the page list and the URLs, in the NPM format most FHIR tools read. It is the first choice for generating implementation artifacts, because it carries all the rules that make a profile valid. It does not replace reading the specification. See [validating profiles and resources](http://hl7.org/fhir/R4/validation.html) in the FHIR specification.

- [Package (compressed folder)](../package.tgz){::download="true"}

This guide is bilingual, and the publisher additionally produces one package per language, each carrying the designations of that language:

- [Package, English](../de.medizininformatikinitiative.kerndatensatz.laborbefund.en.tgz){::download="true"}
- [Package, German](../de.medizininformatikinitiative.kerndatensatz.laborbefund.de.tgz){::download="true"}

### Downloadable Copy of the Specification

A copy of this guide for local hosting:

- [Downloadable Copy (compressed folder)](../full-ig.zip)

### Examples

All examples of this guide:

- [XML (compressed folder)](../examples.xml.zip)
- [JSON (compressed folder)](../examples.json.zip)

### Definitions and Expansions

The conformance resources on their own, and the value sets with their expansions resolved:

- [Definitions, XML](../definitions.xml.zip) · [JSON](../definitions.json.zip)
- [Expansions, XML](../expansions.xml.zip) · [JSON](../expansions.json.zip)

### Consolidated CSV and Excel Representations

All profile information in a single table, useful for reviewing element properties across profiles:

- [CSV (compressed folder)](../csvs.zip)
- [Excel (compressed folder)](../excels.zip)

### Schematrons

- [Schematrons (compressed folder)](../schematrons.zip)

### Implementation Guide Resource

The technical definition of this publication, including its dependencies and publishing parameters:

- [ImplementationGuide resource (JSON)](ImplementationGuide-mii-ig-labor.json)
- [ImplementationGuide resource (rendered)](ImplementationGuide-mii-ig-labor.html) — the resolved package versions, the global profiles and the expansion parameters

### Sources

The FSH sources and the editable PlantUML diagram are maintained in the [GitHub repository](https://github.com/medizininformatik-initiative/kerndatensatzmodul-labor).

### Version History

For earlier versions and the change history, see [Versioning](version-history.html).
