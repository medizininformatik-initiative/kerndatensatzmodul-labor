<!-- markdownlint-disable MD041 -->
<!-- Intro fuer die Artefaktseite der ImplementationGuide-Ressource. Der
     Publisher rendert die Seite nur, wenn dieses Fragment existiert und nach
     der IG-ID benannt ist; ohne sie bleibt sie leer - keine Dependency-
     Tabelle, keine Cross-Version-Analyse, keine Copyright-Angaben.
     Uebernommen aus mii-kds-module-template v0.13.2; die deutsche Fassung
     unter input/translations/de/pagecontent/ muss dasselbe sagen. -->
This ImplementationGuide resource defines the technical details of this
publication, including dependencies and publishing parameters.

- [XML](../ImplementationGuide-mii-ig-labor.xml)
- [JSON](../ImplementationGuide-mii-ig-labor.json)

### Cross Version Analysis

{% include cross-version-analysis-en.xhtml %}

### IG Dependencies

This IG contains the following dependencies on other IGs.

{% include dependency-table-en.xhtml %}

> **Where the versions come from.** Every package in the table is pinned
> directly in
> [`sushi-config.yaml`](https://github.com/medizininformatik-initiative/kerndatensatzmodul-labor/blob/main/sushi-config.yaml)
> (`dependencies:`) — including `hl7.terminology.r4` (THO) and
> `hl7.fhir.uv.extensions.r4`, and those two deliberately so: the IG
> Publisher's
> [automatic-packages rule](https://build.fhir.org/ig/FHIR/ig-guidance/versions.html#automatic-packages)
> consults only this guide's **own** dependency list, so without a direct pin
> every build would silently inject the latest THO/extensions release — a
> version pinned by the MII meta package alone cannot control the build
> (verified in the publisher source at the pinned release). A weekly check
> warns when these two pins drift from what the pinned meta package ships,
> and the exact versions a concrete build used are recorded in its
> `qa-versions.json` output.
{: .ig-highlight .ig-highlight-grey}

### Global Profiles

This IG declares the following global profiles — profiles that apply to every
instance of their resource type exchanged under this guide. An empty table
means this module declares none.

{% include globals-table-en.xhtml %}

### Copyrights

{% include ip-statements-en.xhtml %}

### IG Parameter Settings and Expansion Parameters

Expansion parameters are query parameters that can be passed to a `ValueSet`
`$expand` operation to control how the ValueSet is expanded — that is, how the
full list of codes is generated from the ValueSet definition. The
[IG Parameters](https://hl7.org/fhir/tools/en/CodeSystem-ig-parameters.html)
used for this IG are declared in
[`sushi-config.yaml`](https://github.com/medizininformatik-initiative/kerndatensatzmodul-labor/blob/main/sushi-config.yaml)
(`parameters:`). A module that pins its expansion parameters through a CRMI
manifest additionally links the generated `Parameters` resource from here (see
the commented manifest blocks in `sushi-config.yaml` and the Metadata Overview
page, if the module keeps it).
