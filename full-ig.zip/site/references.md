The modelling of the dataset for the Laboratory Report module contains references to the following projects:

- [International Patient Summary (IPS)](https://hl7.org/fhir/uv/ips/STU1.1/).

The module also builds on the core specification of HL7 FHIR, in particular the resources DiagnosticReport and Observation. In terms of content, the requirements of the German Medical Association's guideline on quality assurance in laboratory medicine (Rili-BÄK) are taken into account.
This specification was designed on the basis of the description of the MII Core Dataset in the version of 10 March 2017 ([PDF](https://www.medizininformatik-initiative.de/sites/default/files/inline-files/MII_04_Kerndatensatz_1-0.pdf)).
